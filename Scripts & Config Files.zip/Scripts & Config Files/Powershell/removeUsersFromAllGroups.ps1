﻿# Location of the OU that will contain disabled user objects
Import-Module activedirectory

$disabledUsersOU = "OU=AccountsDisabled,OU=Users,OU=StorageCraft,DC=stc,DC=local"


# Remove users from all groups within the disabled users OU
$disabledUsers = get-aduser -server stc-ut-dc1 -Filter * -SearchBase $disabledUsersOU -Properties memberOf

foreach ( $user in $disabledUsers ) {
    $user.Name
    $Groups = $user.memberOf | ForEach-Object { Get-ADGroup $_ }
    $Groups | ForEach-Object { Remove-ADGroupMember -server stc-ut-dc1 -Identity $_ -Members $user -Confirm:$false}
}