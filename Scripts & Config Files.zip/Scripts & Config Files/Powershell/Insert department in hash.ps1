﻿$hashFile = "C:\Users\rjohnson\Documents\Hashcrack\hashes.txt"
$crackedFile = "C:\Users\rjohnson\Documents\Hashcrack\cracked.txt"
$file1 = Get-Content $hashFile
$file2 = Get-Content $crackedFile
$department = ($dn -split '[,\=]')[3]

# Get each user in the hash table
foreach ($user in $file1) {
    
    $username = ($user -split ':')[0]
    $hash = ($user -split ':')[2]

    

    
    foreach ($item in $file2) {
        
        $crackedHash = ($item -split ':')[0]
        $crackedPass = ($item -split ':')[1]

        if ($hash -eq $crackedHash) {
            if ($(get-aduser $username -Properties enabled,department).enabled -eq "True") {
                #Get-ADUser $username -Properties enabled |ft name,enabled -HideTableHeaders
                $department = Get-ADUser $username -Properties department | select -ExpandProperty department
                Write-Output "$username, $department, $hash, $crackedPass"
            }
        }
    }#>
}