﻿Get-Content .\words_alpha.txt | ForEach-Object {
    $word = $_
    
    if (!($word.length -gt 10) -and !($word.Length -lt 3)) { 
        #Out-File $word "C:\Users\rich\Desktop\wificrack.txt" -
        $word | out-file "C:\Users\Rich\Desktop\wifiCracking.txt" -Append
    }
}