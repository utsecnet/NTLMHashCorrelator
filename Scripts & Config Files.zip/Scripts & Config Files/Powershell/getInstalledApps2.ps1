﻿$InputFile = "C:\users\rjohnson\Documents\Installed Apps\Installed_Programs.csv"
$OutputFile = "C:\users\rjohnson\Documents\Installed Apps\All-Installed_Programs.csv"

# delete the existing output file
if ($OutputFile | Test-Path) {
    Remove-Item -Path $OutputFile -Force
}

# Create a new output file
if (!($OutputFile | Test-Path)) {
    New-Item -ItemType "file" -path $OutputFile -Force
}

# fill the output file
Get-Content $InputFile | ForEach-Object {
    $_ >> $OutputFile
}