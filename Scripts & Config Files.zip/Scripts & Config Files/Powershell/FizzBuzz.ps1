﻿<#

I was asked during an interview to write a script that counted from 1 to 100 and for every number that is divisible by 3, output "fizz" and for every number divisible by 5, output "buzz".  If they are both divisible by 3 and 5, output "fizzbuzz".  This is what I came up with.

#>

# Variables
###########
$limit = 100
$valueOne = 3
$valueTwo = 5

# GO TIME!
##########

# For each number from 1 to 100...
For ( $i=1; $i -le $limit; $i++ ) {
    $number = $i
    
    # If divisible by 3 and 5, write FizzBuzz
    if ( $number % $valueOne -eq 0 -and $number % $valueTwo -eq 0 ) {
        $output = "FizzBuzz"
    }
    # If only divisible by $valueOne, write Fizz
    elseif ( $number % $valueOne -eq 0 ) {
        $output = "Fizz"
    }
    # If only divisible by $valueTwo, write Buzz
    elseif ( $number % $valueTwo -eq 0 ) {
        $output = "Buzz"
    }
    # Otherwise, write out the number
    else {
        $output = $number
    }

    Write-Output $output
}