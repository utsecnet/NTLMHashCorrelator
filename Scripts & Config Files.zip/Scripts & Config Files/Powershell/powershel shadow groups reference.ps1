import-module activedirectory

# Count of all computer objects by OS
get-adcomputer -searchbase "OU=computers,ou=storagecraft,dc=stc,dc=local" -filter * -properties operatingsystem | ? { ($_.distinguishedname -notlike "*AccountsDisabled*") -and ($_.operatingsystem -like "Windows*") } | group-object operatingsystem | sort-object count | ft count,name

# Get a list of all the OUs under Laptops and Desktops
$LapOUs = Get-ADOrganizationalUnit -SearchBase "OU=Laptops,OU=Workstations,OU=STC-Utah,OU=Computers,OU=StorageCraft,DC=stc,DC=local" -Filter * -SearchScope OneLevel | select -ExpandProperty name
$DesOUs = Get-ADOrganizationalUnit -SearchBase "OU=Desktops,OU=Workstations,OU=STC-Utah,OU=Computers,OU=StorageCraft,DC=stc,DC=local" -Filter * -SearchScope OneLevel | select -ExpandProperty name
$OUs = $LapOUs + $DesOUs | Select-Object -Unique

# Append -Computers to each OU name, so when the group gets created, it looks like "Department-Computers"
$LapOUGroups =  $LapOUs | foreach-object{ "$_-Computers" }
$DesOUGroups =  $DesOUs | foreach-object{ "$_-Computers" }
$Groups = $LapOUGroups + $DesOUGroups | Select-Object -Unique

# Create the DNs of all the OUs
$LapOUDN = $LapOUs | foreach-object{ "OU=$_,OU=Laptops,OU=Workstations,OU=STC-Utah,OU=Computers,OU=StorageCraft,DC=stc,DC=local" }
$DesOUDN = $DesOUs | foreach-object{ "OU=$_,OU=Desktops,OU=Workstations,OU=STC-Utah,OU=Computers,OU=StorageCraft,DC=stc,DC=local" }
$OUDN = $LapOUDN + $DesOUDN | Select-Object -Unique

# All Group DNs
$GroupDN = $Groups | ForEach-Object{ "CN=$_,OU=Computers,OU=SecurityGroup,OU=STC-Utah,OU=Groups,OU=StorageCraft,DC=stc,DC=local" }

# If the group does not exist in Active Directory, create it
foreach ( $i in $Groups ) {
    if (!(Get-ADGroup -Filter {name -eq $i} )) {
        Write-Host Will create group $i...
        New-ADGroup -Server stc-ut-dc1 -Path "OU=Computers,OU=SecurityGroup,OU=STC-Utah,OU=Groups,OU=StorageCraft,DC=stc,DC=local" -Name $i -GroupScope DomainLocal -GroupCategory Security     
    }
}

# Computers get added to the shadow groups if not a member already, and they get removed if they are no longer members.
for ( $i=0;$i -lt $GroupDN.Count;$i++ ) {
    # Remove computer if no longer a member
    Get-ADGroupMember -Identity $GroupDN[$i] | Where-Object {$_.distinguishedName -NotMatch $LapOUs[$i]} | ForEach-Object {Remove-ADPrincipalGroupMembership -Identity $_ -MemberOf $GroupDN[$i] -Confirm:$false}
    Get-ADGroupMember -Identity $GroupDN[$i] | Where-Object {$_.distinguishedName -NotMatch $DesOUs[$i]} | ForEach-Object {Remove-ADPrincipalGroupMembership -Identity $_ -MemberOf $GroupDN[$i] -Confirm:$false}

    # Add computer if not already a member
    Get-ADComputer -SearchBase $LapOUDN[$i] -LDAPFilter "(!memberOf=$GroupDN[$i])" | ForEach-Object {Add-ADPrincipalGroupMembership -Identity $_ -MemberOf $GroupDN[$i]}
    Get-ADComputer -SearchBase $DesOUDN[$i] -LDAPFilter "(!memberOf=$GroupDN[$i])" | ForEach-Object {Add-ADPrincipalGroupMembership -Identity $_ -MemberOf $GroupDN[$i]}
}

# Mass convert group type from Local to GLobal
# You may need to run the top line twice before runing the second line
Get-ADGroup -server stc-ut-dc1 -SearchBase "OU=ShadowGroups-Computers,OU=SecurityGroups,OU=Groups,OU=StorageCraft,DC=stc,DC=local" -filter * | ForEach-Object { Set-ADGroup $_ -GroupScope Universal }
Get-ADGroup -server stc-ut-dc1 -SearchBase "OU=ShadowGroups-Computers,OU=SecurityGroups,OU=Groups,OU=StorageCraft,DC=stc,DC=local" -filter * | ForEach-Object { Set-ADGroup $_ -GroupScope Global }


###############################################

'ou=Inactive,ou=Computer Directory,dc=company,dc=co,dc=uk','ou=Admin Computers,ou=Computer Directory,dc=tdwh,dc=co,dc=uk' |
    ForEach-Object {get-adcomputer -Filter "OperatingSystem -like '*XP*'" -Property * -SearchBase $_}





# Remove computer from group if not a member of OU
$GroupDN = "CN=Domain Servers,OU=Domain Servers,DC=testing,DC=local"
$OU = "OU=Domain Servers,DC=testing,DC=local"

Get-ADGroupMember -Identity $GroupDN | 
Where-Object {$_.distinguishedName -NotMatch $OU} | 
ForEach-Object {Remove-ADPrincipalGroupMembership -Identity $_ -MemberOf $GroupDN -Confirm:$false}


# Computer Name
$computer = Get-ADComputer -SearchBase "$i" -Filter "*" -Server "$server" -Properties *
$computer
            
foreach ( $i in $computer ) {

    $OU = ($i.CsnonicslName -split '/')[-2]
    $pc = ($i.CanonicalName -split '/')[-1]
    $OU + " - " + $pc  
}

# Create a group if it does
try { Get-ADGroup -Server $server -Filter { Name -eq $computerGroupName }}
catch { New-ADGroup -Server $server -Path "$shadowGroupsOU" -Name $computerGroupName -GroupScope DomainLocal -GroupCategory Security -Description $description }

if (!(Get-ADGroup -Server $server -Filter { Name -eq $groupName })) {
        New-ADGroup -Server $server -Path "$shadowGroupsOU" -Name $computerGroupName -GroupScope DomainLocal -GroupCategory Security -Description $description
}


#remove computer from group if not a member of OU
$GroupDN = "CN=Domain Servers,OU=Domain Servers,DC=testing,DC=local"
$OU = "OU=Domain Servers,DC=testing,DC=local"

Get-ADGroupMember -Identity $GroupDN | 
Where-Object {$_.distinguishedName -NotMatch $OU} | 
ForEach-Object {Remove-ADPrincipalGroupMembership -Identity $_ -MemberOf $GroupDN -Confirm:$false}    

$allComputerShadowGroups = Get-ADGroup -Filter '*' -SearchBase $shadowGroupsOU | select -ExpandProperty name
foreach ( $group in $allComputerShadowGroups ) {
    $groupmemebers = Get-ADGroupMember -Identity $group | select -ExpandProperty name
    foreach ( $i in $groupmemebers ) {
        # Get the direct OU that the computer is a member of
        $ou = ($i.CanonicalName -split '/')[-2]
        $ou
        
    }
}

# Add computer to group
Get-ADComputer -Server $server $pc | Add-ADPrincipalGroupMembership -MemberOf $localGroupName
Add-ADGroupMember -Identity <samaccountname of destination group> -Members <samaccountname of group to add in>


#add group to group
Add-ADGroupMember -Server $server -Identity All-$ou$remote-Computers -Members $localGroupName


# Get all groups that are in a specific OU
get-adobject -Filter 'ObjectClass -eq "group"' -SearchBase <<Path to OU>>

Get-ADGroup -SearchBase "OU=ShadowGroups2,OU=SecurityGroups,OU=Groups,OU=StorageCraft,DC=stc,DC=local" -filter *

Get-ADGroup -SearchBase "OU=ShadowGroups2,OU=SecurityGroups,OU=Groups,OU=StorageCraft,DC=stc,DC=local" -Filter { Name -notlike "All-*" }

# Find inactive accounts longer than 90 days
Search-ADAccount -AccountInactive -TimeSpan 90.00:00:00


# Add to group if not already a member
    # Add computer to Region-Department-Computers group if not already a member
    Get-ADComputer -Filter { Name -like $computer.Name } |
        where { (Get-ADGroupMember -Identity $localGroupName |
        Select-Object -ExpandProperty 'Name') -inotcontains $_.samAccountName } |
        Add-ADPrincipalGroupMembership -MemberOf:"$localGroupName"




$member = (Get-ADComputer $computer -Properties memberof).memberof
if (!($member -match "UT-IT-Computers")) {
    write-host "$computer is not a member"
}



# Remove from all groups - target members of an OU (processes on all groups_
$OU = "OU=Terminated Users,DC=test,DC=XXXX, DC=org"
$Users = Get-ADUser -SearchBase $OU -Filter *

Get-ADGroup -Filter * | Remove-ADGroupMember -Members $users -Confirm:$False





# Removes user from all AD groups except Domain Users.
$ADgroups = Get-ADPrincipalGroupMembership -Identity $user | where {$_.Name -ne "Domain Users"}
Remove-ADPrincipalGroupMembership -Identity "$user" -MemberOf $ADgroups -Confirm:$false







$ou = Get-ADComputer -SearchBase $disabledComputersOU -Filter *
foreach ($computer in $ou) {
    $DN = $computer.DistinguishedName
    Get-ADGroup -LDAPFilter "(member=$DN)" | foreach-object {
        if ($_.name -ne "Domain Computers") {remove-adgroupmember -identity $_.name -member $DN -Confirm:$False} 
    }
}

# Remove computer from a group
remove-adgroupmember -Identity "groupname" -Member "computername"


# Remove all members of groups under specified OU
$groups = get-adgroup -searchbase "OU=ShadowGroups-Computers,OU=SecurityGroups,OU=Groups,OU=StorageCraft,DC=stc,DC=local" -filter *
ForEach ( $group in $groups ) { get-adgroupmember $group | foreach-object { Remove-ADGroupMember $group $_ -Confirm:$false } }






# Remove computer from any Region-Department-Computers groups of which it no longer belongs
        foreach ( $group in (Get-ADGroup -Server $server -SearchBase $shadowGroupsComputersOU -Filter { Name -notlike "All-*" }) ) {
            $region = ($group.Name -split '-')[0]
            $department = ($group.Name -split '-')[1]
            $groupName = $region + "-" + $department + "-Computers"
            if ( $region -notlike $country -or $department -notlike $ou ) {
                if (($member -match $groupName)) {
                    Remove-ADGroupMember -Server $server $groupName -Members $computer -Confirm:$false
                    if($?) {
                        if ($debug -eq 1 ) { 
                            Write-Host " - Removed computer $computerName from group: $groupName"
                        }
                    }
                }
            }
        }

# If the computer is a VM, add it to the All-VM-Computers group if not already a member
        if ( $computer.DistinguishedName -like "*OU=VM*" ) {
            if (!($member -match "All-VM-Computers")) {
                Add-ADGroupMember -Server $server All-VM-Computers -Members $computer
                if($?) {
                    if ($debug -eq 1 ) { 
                        Write-Host " - Added computer $computerName to group: All-VM-Computers"
                    }
                }
            }
        }

# If the computer is not a VM, remove it from the All-VM-Computers group
        if (!( $computer.DistinguishedName -like "*OU=VM*" )) {
            if (($member -match "All-VM-Computers")) {
                Remove-ADGroupMember -Server $server All-VM-Computers -Members $computer -Confirm:$false
                if($?) {
                    if ($debug -eq 1 ) { 
                        Write-Host " - Removed computer $computerName from group: All-VM-Computers"
                    }
                }
            }
        }

# Add computer to Country-Department-Computers group if not already a member
        if (!($member -match $localGroupName)) {
            Add-ADGroupMember -Server $server $localGroupName -Members $computer
            if($?) {
                if ($debug -eq 1 ) { 
                    Write-Host " - Added computer $computerName to group: $localGroupName"
                }
            }
        }

# Add groups to the All-<whatever>-Computers groups
    foreach ( $group in (Get-ADGroup -Server $server -SearchBase $shadowGroupsComputersOU -Filter { Name -notlike "All-*" }) ) {
    
        $member = (Get-ADGroup $group -Properties memberof).memberof

        # For debugging
        $groupName = $group.Name
        if ($debug -eq 1 ) {
            Write-Host $groupName
        }

        # Add groups to the All-Workstations-Remote-Computers group
        if ( $group.Name -like "*-Remote-*" ) {
            if (!($member -match "All-WorkstationsRemote-Computers")) {
                Add-ADGroupMember -Server $server -Identity All-WorkstationsRemote-Computers -Members $group
                if($?) {
                    if ($debug -eq 1 ) { 
                        Write-Host " - Added group $groupName to group: All-WorkstationsRemote-Computers"
                    }
                }
            }
        }
    