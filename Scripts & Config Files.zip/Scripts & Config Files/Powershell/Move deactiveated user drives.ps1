﻿# AD Server
$server = "stc-ut-dc1"

# Location of the OU that will contain disabled user objects
$disabledUsersOU = "OU=AccountsDisabled,OU=Users,OU=StorageCraft,DC=stc,DC=local"

# User Objects from all OUs mentioned above:
$userObject = $disabledUsersOU | ForEach-Object { Get-ADUser -Server $server -Filter "*" -SearchBase $_ -Properties "*" }

# Import AD module if not already
If (!(Get-module ActiveDirectory )) {
    Import-Module ActiveDirectory
}

foreach ( $user in $userObject ) {
    Write-Host $user.SamAccountName

    Move-Item "d:\users$\$user.SamAccountName" "h:\" -force
}