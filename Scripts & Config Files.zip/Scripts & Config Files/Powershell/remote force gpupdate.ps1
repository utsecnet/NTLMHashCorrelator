﻿Import-Module activedirectory
Get-ADComputer –Filter 'Name -like "stc-"' -Searchbase "ou=gpo-testing,ou=servers,ou=stc-utah,ou=computers,ou=storagecraft,dc=stc,dc=local" 
    | foreach{ Invoke-GPUpdate –Computer $_.name -Force -RandomDelayInMinutes 0}