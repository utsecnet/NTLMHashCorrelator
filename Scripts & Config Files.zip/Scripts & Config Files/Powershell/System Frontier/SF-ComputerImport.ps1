﻿# ==============================================================================================
# 
# NAME: SFComputerImport.ps1
# 
# AUTHOR: Jay Adams, Noxigen LLC. Copyright (c) Noxigen LLC. All rights reserved.
# DATE  : 2/6/2015
# 
# COMMENT: Import computers into System Frontier using the SF API.
# 
# ==============================================================================================

# URL to your System Frontier installation API
# Example: $url = "http://localhost:8080/api/computer"
$url = "https://s-ut-sfrontier/api/computer"

# This number should be less than or equal to the number of nodes you are licensed for
$resultLimit = 250

# Active servers
$ldapFilter = '(&(objectCategory=computer)(operatingSystem=Windows*)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))'

# Example: Active workstations
#$ldapFilter = '(&(objectCategory=computer)(!operatingSystem=Windows Server*)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))'

# Example: All active computers
#$ldapFilter = '(&(objectCategory=computer)(!(userAccountControl:1.2.840.113556.1.4.803:=2)))'

# Get information from Active Directory
$DirSearcher = New-Object System.DirectoryServices.DirectorySearcher([adsi]'')
$DirSearcher.PageSize = 1000
$DirSearcher.Filter = $ldapFilter

$i = 0

# Loop through each AD object returned
$DirSearcher.FindAll().GetEnumerator() | ForEach-Object {
	$i++
	if ($i -gt $resultLimit) { break }
	
	# Populate required fields (Only for import and add operations. $hostname is the minimum for update operations)
	# Available actions: import, add, update.
	# "import" will always add a new computer if it doesn't exist and 
	# update the first matching one it finds in the database.
	# =========================================================================
	$target = "computer"
	$action = "import"
	$hostname = $_.Properties.dnshostname[0]
	
	
	# These fields aren't required for the "update" action
	$status = $_.Status
	$environment = $_.Environment
	$description = $_.Description
	# =========================================================================
	# End required fields
	
	Write-Output $hostname
	
	# Set the following to $true to grab WMI data for each server
	# Populate optional field values here
	
	$ipInfo = Test-Connection $hostname -Count 1 -ErrorAction Ignore
	if ($ipInfo -ne $null) { $ipv4address = ($ipInfo).IPv4Address[0].ToString() } else { $ipv4address = "0.0.0.0" }
	
	
	$computerInfo = $null
	$biosInfo = $null
	$osInfo = $null
	
	try {
		$computerInfo = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $hostname
		$biosInfo = Get-WmiObject -Class Win32_Bios -ComputerName $hostname
		$osInfo = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $hostname
	} catch {
		# WMI connection failed
	}
	
	
	# Build the payload to submit to the web api
	$postData = New-Object System.Collections.Specialized.NameValueCollection
	
	# Required fields...
	$postData.Add("target", $target)
	$postData.Add("action", $action)
	$postData.Add("hostname", $hostname)
	# End required fields
	
	# These fields aren't required for the "update" action
	$postData.Add("status", $status)
	$postData.Add("environment", $environment)
	$postData.Add("description", $description)
	
	
	# Add optional fields
	# NOTE: You can add as many fields as you want here as long as the names correspond 
	#	to column names in teh System Frontier database.
	$postData.Add("IPv4Address", $ipv4address)
	
	if ($computerInfo -ne $null) {
		$postData.Add("Manufacturer", $computerInfo.Manufacturer)
		$postData.Add("Model", $computerInfo.Model)
		$postData.Add("Memory", [math]::truncate($computerInfo.TotalPhysicalMemory/1MB))
	}
	
	if ($biosInfo -ne $null) {
		$postData.Add("SerialNumber", $biosInfo.SerialNumber)
	}
	
	if ($osInfo -ne $null) {
		$postData.Add("OperatingSystem", $osInfo.Caption)
	}
	
	# Submit the operation to the SF API using the currently logged on user's credentials	
    $webClient = New-Object "System.Net.WebClient"
    $webClient.UseDefaultCredentials = $true
	$webClient.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
    
    $result = $webClient.UploadValues($url, $postData)
	
	# Append results for this record to a log file
	$out = [System.Text.Encoding]::ASCII.GetString($result)
	$out | Out-File -FilePath .\sf-import.log -Append
	
	#Output to the screen
	"  Result: $($out)"
}
