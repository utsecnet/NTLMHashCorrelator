﻿
# for each OU under COMPUTERS like "*Workstations*"
set acl that gives "LAPS-AllWorkstations-Password--Read" read access on the password and on expiration time



# for each OU under COMPUTERS like "*Servers*"
set acl that gives "LAPS-AllServers-Password--Read" read access on the password and on expiration time