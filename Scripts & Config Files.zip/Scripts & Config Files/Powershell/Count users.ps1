﻿$cc = (Get-ADUser -filter * -SearchBase "OU=Corporate,OU=Users,OU=UpWell,DC=UPWELL,DC=COM" | measure).count
$pharm = (Get-ADUser -filter * -SearchBase "OU=Pharmacies,OU=Users,OU=UpWell,DC=UPWELL,DC=COM" | measure).count
$total = $cc + $pharm
$total