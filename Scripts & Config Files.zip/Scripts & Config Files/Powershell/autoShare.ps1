﻿<#
.NOTES
    Comment out line 16 and uncomment line 17 when you are ready to run it.  You will need to adjust line 17 to include the ACLs and other share properties you want.  
#>

###########
# Functions
###########

# Check if the share exists, if not, create it
function createShare ($shareName) {
    # If the share doesn't exist...
    #$shareName
    if (!(get-smbshare -Name $shareName -ErrorAction SilentlyContinue)) {
        
        # ...Create the share
        Write-Output "We would create a share called: $shareName"
        #New-SmbShare -Name $shareName
    }
}

###########
# Variables
###########

# Define the top level directory
$topLevel = "d:\spx images"

# Every direcotry in $topLevel
$directories = Get-ChildItem $topLevel -Recurse -Directory

# an array containing all the folders we want to share
$directoriesWeWantToShare = New-Object System.Collections.ArrayList

#########
# Action!
#########

# Collect all the directories we want to share into an array called $bottomLevelDirectories
foreach ($directory in $directories) {

    # Only find directories that have no child directories (deepest levels)
    if ((Get-ChildItem $directory.fullname -Directory).count -eq 0) {
        
        # Get the parent of the deepest directory
        $parent = (Get-Item $directory.FullName).Parent.FullName

        # Add the parent directory to the $directoriesWeWantToShare array
        [void] ($directoriesWeWantToShare.Add($parent))
    }
}

# Remove any duplicate directories from the array and create the share
#$direcotriesWeWantToShare | Get-Unique | ForEach-Object {
    #createShare $_
    #write-output "$_"
#}

foreach ($directory in $directoriesWeWantToShare) {
    #Write-Output $directory
    createShare $directory
}