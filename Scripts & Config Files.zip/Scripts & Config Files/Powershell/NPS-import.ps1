﻿<#

.DESCRIPTION 
    - Copies the NPS configuration from a specified master NPS server into the NPS server on the local host (the host this script runs on).

.NOTES
    NAME: NPS-import.ps1
    AUTHOR: Rich Johnson
    EMAIL: rich.johnson@storagecraft.com
    REQUIREMENTS:
    Change Log:
        2016-09-06 - Initial Creation
    TODO
        write it :)
#>
 

# Your Primary Network Policy Server you want to copy the config from.
$master = "s-ut-nps-2"

# A temporary location to store the XML config. Use a UNC path so that the primary can save the XML file across the network. Be sure to set secure permissions on this folder, as the configuration including pre-shared keys is temporarily stored here during the import process.
$NPSConfigTempFile = "\\server2\C$\Temp\NPSConfigTemp\NPSConfig-$master.xml"
 
 
# Create an NPS Sync Event Source if it doesn't already exist
if (!(get-eventlog -logname "System" -source "NPS-Sync")) {
    new-eventlog -logname "System" -source "NPS-Sync"
}
 
# Write an error and exit the script if an exception is ever thrown
trap {
    write-eventlog -logname "System" -eventID 1 -source "NPS-Sync" -EntryType "Error" -Message "An Error occured during NPS Sync: $_. Script run from $($MyInvocation.MyCommand.Definition)"; exit
}
 
# Connect to NPS Master and export configuration
$configExportResult = invoke-command -ComputerName $master -ArgumentList $NPSConfigTempFile -scriptBlock {param ($NPSConfigTempFile) netsh nps export filename = $NPSConfigTempFile exportPSK = yes}
 
# Verify that the import XML file was created. If it is not there, it will throw an exception caught by the trap above that will exit the script.
$NPSConfigTest = Get-Item $NPSConfigTempFile
 
# Clear existing configuration and import new NPS config
$configClearResult = netsh nps reset config
$configImportResult = netsh nps import filename = $NPSConfigTempFile
 
# Delete Temporary File
remove-item -path $NPSConfigTempFile
 
# Compose and Write Success Event
$successText = "Network Policy Server Configuration successfully synchronized from $master.
 
Export Results: $configExportResult
 
Import Results: $configImportResult
 
Script was run from $($MyInvocation.MyCommand.Definition)"
 
write-eventlog -logname "System" -eventID 1 -source "NPS-Sync" -EntryType "Information" -Message $successText