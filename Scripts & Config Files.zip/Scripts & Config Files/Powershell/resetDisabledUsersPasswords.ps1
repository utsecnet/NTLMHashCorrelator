﻿<#
.SYNOPSIS
    Reset terminated user account passwords in AD

.DESCRIPTION
    - The randomPassword function will generate a random password with a minimum length of 64, and max length of 92, 
      then return $newPassword

.NOTES
    NAME: resetDisabledUsersPasswords.ps1
    AUTHOR: Rich Johnson
    EMAIL: rjohnson@alliancehealth.com
    REQUIREMENTS: It is required that you disable any accounts you want to reset passwords.  If you are not at least doing this
                  you are doing IT wrong!  It is also recommended that you are putting the disabled users into a dedicated OU.
    Change Log:
        2017-10-18 - Initial Creation
#>

############
# Variables
############

# Define the disabled users OU
$disabledUsersOU = "OU=Corporate,DC=ALLIANCEHEALTH,DC=COM"

# Get a list of all disabled users
$disabledusers = get-aduser -filter 'enabled -eq $false' -Properties department -SearchBase $disabledUsersOU

############
# Fucntions
############

function randomPassword {

    # Generate a random length between 64 - 92 chars
    $passwordLength = get-random -Minimum 34 -Maximum 92
    $newPassword = [System.Web.Security.Membership]::GeneratePassword($passwordLength,10)
    return $newPassword
}

#################
# Aaaand Action!
#################

# Import AD module if not already
If (!(Get-module ActiveDirectory )) {
    Import-Module ActiveDirectory
}

# Need to add an assembly that holds our "GeneratePassword" method, so we don't have to reinvent the wheel
Add-Type -AssemblyName System.Web

try {
    $disabledusers | ForEach-Object {
        $username = $_.SamAccountName
        $password = randomPassword
        
        $username
        # Rest the passwords
        Set-ADAccountPassword -Identity $username -Reset -NewPassword (ConvertTo-SecureString -AsPlainText "$password" -Force)
        #Write-Output "$username . . . . . . . . . . $password"
    }
}
catch {
    Write-Output $Error[0]
}