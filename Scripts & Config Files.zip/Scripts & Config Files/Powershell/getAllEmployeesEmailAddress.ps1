﻿$ADServer = "pslwsdc01.upwell.com"
$top = "OU=Users,OU=UpWell,DC=UPWELL,DC=COM"
$allOUs = Get-ADOrganizationalUnit -Server $ADServer -SearchBase $top -Filter 'Name -like "*Corporate*" -OR Name -like "*Pharmacies*"'
$allEmployees = $allOUs | ForEach-Object { Get-ADUser -Server $ADServer -Filter {emailaddress -like "*@*"} -SearchBase $_ -Properties * }

$allEmployees | ForEach-Object {
    $user = $_.name
    $email = $_.emailaddress
    $department = $_.department
    $manager = ($_.manager -split '[,\=]')[1]

    Write-Output "$user,$email,$department,$manager"
}