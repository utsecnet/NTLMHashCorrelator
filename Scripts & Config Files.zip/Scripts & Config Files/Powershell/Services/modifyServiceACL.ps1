﻿
#command = @'
#"c:\Program Files (x86)\Windows Resource Kits\Tools\subinacl.exe" /service bbb /grant=stc\ut-noc-users=STOP
#'@

#Invoke-Expression -Command:$command

#Get-Service | ForEach-Object { Invoke-Expression -Command:$command }


#& "\\stc-file\stc\it\Windows Resource Kit\subinacl.exe" /service bbb /grant=stc\rj=STOP

$serv = get-service
$serv -replace ' ','` '
$domain = "stc.local"
$user = "ut-noc-users"

$serv | ForEach-Object { CMD /C "c:\Program Files (x86)\Windows Resource Kits\Tools\subinacl.exe" /service $_.DisplayName /grant=$domain\$users=STOP }

# To Revoke uncomment out the following line
# get-service | ForEach-Object { CMD /C "c:\Program Files (x86)\Windows Resource Kits\Tools\subinacl.exe" /service $_ /revoke=$domain\$users }
