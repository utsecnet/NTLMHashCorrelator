﻿<#
SYNOPSIS 
    This script reads from a list of services in a file called list.txt, and for each
    service in the file, it creates or deletes the service on the local machine depending
    on the argument passed.

NOTES
    BulkCreateDeleteServices.ps1
    AUthor: Rich Johnson | StorageCraft Technology Corporation
    Last Modified Date: 2015-09-10

EXAMPLES

    PS> ./BulkCreateDeleteServices.ps1 create
        This command will create all the services in list.txt

    PS> ./BulkCreateDeleteServices.ps1 delete
        This command will delete all the services in list.txt

PARAMETERS
    create - if you want to create the services in the txt file
    delete - if you want to delete the services in the txt file

CHANGE LOG
    2015-09-10 - Initial Creation

#>

# Variables
# THESE ARE SPECIFIC TO YOUR ENVIRONMENT AND MUST BE CHANGED!

# Server name of your main Domain Controller
$server = "stc-ut-dc1"

# Location of the OU that will contain all your service control groups
$serviceGroupsOU = "OU=ServiceAccountControl,OU=SecurityGroups,OU=Groups,OU=StorageCraft,DC=stc,DC=local"

# Username or group name you want to add to all the newly created groups
$members = "IT-NOC"

# Defile the file with the list of services
$file = Get-Content list.txt

# Define the action of create or delete
$action = $args[0]

import-module activedirectory
if ( $action -eq "create" ) {
    
    foreach ( $i in $file ) {
        # Create a new service
        try { new-service -name $i -binaryPathName test.exe -ErrorAction Stop}
        catch { "ERROR - Maybe the service already exists?" }

        #remove all spaces so AD groups dont have spaces.
        $svc = $i -replace '\s',''
        $svc

        # Create AD groups based on each service
        try { get-adgroup SC-$svc-ReadStartStop -ErrorAction stop }
        catch {
            New-ADGroup -Server $server -Path "$serviceGroupsOU" -Name SC-$svc--ReadStartStop -GroupScope DomainLocal -GroupCategory Security -Description "Members of this group can Stop, Start, and restart the service in the name of this group."
            Add-ADGroupMember -Server $server SC-$svc--ReadStartStop $members
        }
    }
}

elseif ( $action -eq "delete" ) {
 
    foreach ( $i in $file ) {
        cmd /c sc delete $i
    }
}

else {
    "ERROR - Invalid Parameter." 
    "Syntax is : ./BullCreateDeleteServices.ps1 [create|delete]"
}