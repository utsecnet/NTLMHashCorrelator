﻿$file = Get-Content list.txt

foreach ( $i in $file ) {
        $service = $i.Split(",")
        # Create a new service
        new-service -name $service[0] -binaryPathName test.exe
}

foreach ( $i in $file ) {
        $svcName = $i.Split(",")
        $service = Get-WmiObject -Class Win32_Service -Filter "Name=$($svcName[0])"
        $service.delete()
}