﻿<#
SYNOPSIS 
    This script enumerates user accounts within a specified OU used for disabled accounts and
    performs the following actions on each object within:
    Disables (if not already), Remove from GAL, remove from any DL in exchange, <more to come>

NOTES
    DisableAccounts.ps1
    AUthor: Rich Johnson | StorageCraft Technology Corporation
    Last Revision: 2015-11-11

EXAMPLES

    PS> ./DisableAccounts.ps1
        This will simply run the script and process disabled users.

PARAMETERS
    This script takes no parameters.

CHANGE LOG
    2015-11-11 - Updated to use only one OU for disabled accounts.
    2015-04-24 - Initial creation

#>

# Import AD module if not already
If (!(Get-module ActiveDirectory )) {
    Import-Module ActiveDirectory
}

# All locations for disabled accounts
$DisabledUsers = "OU=AccountsDisabled,OU=Users,OU=StorageCraft,DC=stc,DC=local"

# Disable user account if not already disabled
Get-ADUser -Filter * -SearchBase "$DisabledUsers" | Where -Property enabled | Disable-ADAccount
    
# Remove users from GAL
Get-ADUser -filter * -SearchBase "$DisabledUsers" | Set-ADUser -Replace @{msExchHideFromAddressLists=$true}
Get-ADUser -filter * -SearchBase "$DisabledUsers" | Set-ADObject -Clear showinAddressBook

# Build list of users from all the users in the DisabledUsers OU
$Users = Get-ADUser -Filter * -SearchBase "$DisabledUsers" -Properties memberOf

#Remove each user from all groups they are a member of
foreach ( $i in $Users ) {
    $Groups = $i.memberOf | ForEach-Object { Get-ADGroup $_ }
    $Groups | ForEach-Object { Remove-ADGroupMember -Identity $_ -Members $i -Confirm:$false}
}