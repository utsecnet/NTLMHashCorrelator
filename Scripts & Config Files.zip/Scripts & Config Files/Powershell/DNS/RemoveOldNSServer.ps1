﻿Import-Module ActiveDirectory,DNSServer

#Inputs the DC/DNS Server that has been removed from the environment into the $UnknownDNSServer variable.

$UnknownDNSServer = Read-Host "Enter the old Name Server's FQDN"

#Finds the PDC Emulator and stores it in the $PDCE variable.

$PDCE = Get-ADDomainController -Discover -Service PrimaryDC

#Finds the DNS zones on the PDCE

$DNSZones = Get-DnsServerZone -ComputerName $PDCE

#For each of the zones in the DNSZones variable, it removes the old NS record from the zone that's defined in $UnknownDNSServer.

$DNSZones | ForEach-Object {

Try {$_ | Remove-DNSServerResourceRecord –Name “@” –RRType NS –RecordData $UnknownDNSServer -ComputerName $PDCE -Force}

Catch{[System.Exception] "UH oh..got an error"}

}