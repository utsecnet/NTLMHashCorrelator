﻿<#
    BulkUpdateNSRecords.ps1
    Created by Rich Johnson for StorageCraft Technology Corporation
    Last updated: 2015-07-13

    This script updates NS records for all forward lookup zones
#>

# Accept the included parameter as a variable/array
$file=$args[0]
$dns1="10.1.0.9"
$ns1="dns1.storagecraft.com"
$ns2="dns2.storagecraft.com"
$ns3="dns3.storagecraft.com"
$ns4="dns4.storagecraft.com"
$ns=$ns1 + $ns2 + $ns3 + $ns4

if ($file -eq $NULL) 
{ 
    "Invalid Parameters." 
    "Syntax is : BulkUpdateNSRecords.ps1 <file>" 
}

else
{
    $domainList = Get-Content $file
    foreach ($i in $domainList) {
        $domain = $i
        $zoneFile=$domain + ".dns"

        "===============BEGIN $domain=============="
        
        # Delete old NS records
         Remove-DnsServerResourceRecord -name "@" -RRType NS -ZoneName shadowprotect.ch -Force

        # Create new NS records
        foreach ($i in %ns) {
            Add-DnsServerResourceRecord -NS -Name "@" -ZoneName shadowprotect.ch -NameServer $i
        }     

        "===============END $domain=============="
    } 
}