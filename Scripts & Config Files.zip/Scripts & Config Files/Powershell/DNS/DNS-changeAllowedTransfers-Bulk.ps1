# changeAllowedTransfers.ps1
# Written by Ethan Dodge (ethan.dodge@storagecraft.com) on 3/13/2014 for use at StorageCraft Technology Corporation
# This script takes 1 parameter, a text file, and changes the list of allowed zone transfers for each domain in that text file to allow transfers to the specified servers.
# **WARNING** This script does not add the servers to the list of allowed zone transfers, but overwrites the current list

$file=$args[0]
$dns1="10.1.0.10"
$dns3="10.1.3.18"
$dns4="10.1.3.19"

if ($file -eq $NULL) 
{ 
    "Invalid Parameters." 
    "Syntax is : createPrimaryBulk.ps1 <file>" 
}

else
{
    $domainList = Get-Content $file

    foreach ($element in $domainList)
    {
        $domain = $element
        $zoneFile=$domain + ".dns"

        "===============BEGIN $domain=============="

        "Attempting to change and configure allowed zone transfers for $domain"
        dnscmd localhost /zoneresetsecondaries $domain /securelist $dns1 $dns2 $dns3 $dns4 /Notify 

        "===============END $domain=============="
    }
      
}