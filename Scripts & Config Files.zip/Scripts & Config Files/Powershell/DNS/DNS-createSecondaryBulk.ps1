# createSecondaryBulk.ps1 - 16/06/2013 - Keith Langmead 
# Modified by Ethan Dodge (ethan.dodge@storagecraft.com) on 3/12/2014 for use at StorageCraft Technology Corporation
# This script takes 1 parameters, a list of domain names, and creates a secondary Forward Lookup Zone on the localhost for each domain with that A record
# It's sister script, createPrimaryBulk.ps1, should have been run on the master DNS server prior to running this script. 
 
$file=$args[0] 
$master="10.1.0.9" 
 
if ($file -eq $NULL -or $master -eq $NULL) 
{ 
    "Invalid Parameters." 
    "Syntax is : createSecondaryBulk.ps1 dnsZones.txt" 
} 

else 
{ 
    $domainList = Get-Content $file
    $dnsserver="localhost"

    foreach ($i in $domainList)
    {
        $domain = $i
        $zoneFile=$domain + ".dns"

        "===============BEGIN $domain=============="
        
        try 
        { 
            "Adding $domain to $dnsserver" 
            write-output "Adding $domain to $dnsserver"  
            # Create the secondary zone on the current DNS server 
            Add-DnsServerSecondaryZone -Name $domain -ZoneFile $zoneFile -MasterServers $master -ComputerName $dnsserver 
            "Successfully added $domain to $dnsserver" 
            write-output "Successfully added $domain to $dnsserver"  
        } 
        catch 
        { 
            # If an error occurs adding the zone generate an error 
            "WARNING! An error occurred adding $domain to $dnsserver" 
            $Error[0].Exception 
            write-output "WARNING! An error occurred adding $domain to $dnsserver" 
            write-output $Error[0].Exception 
        } 

        "================END $domain==============="
    } 
}