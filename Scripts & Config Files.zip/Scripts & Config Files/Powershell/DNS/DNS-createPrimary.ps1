# createPrimary.ps1
# Written by Ethan Dodge (ethan.dodge@storagecraft.com) on 3/12/2014 for use at StorageCraft Technology Corporation
# This script takes 2 parameters, a domain name and an A record, and creates a Forward Lookup Zone on the localhost for that domain with that A record
# It's sister script, createSecondary.ps1, then needs to be run on all DNS servers to which the zone should be copied as a secondary zone

$domain=$args[0]
$aRecord=$args[1]
$zoneFile=$domain + ".dns"
$secondaryServer="10.1.0.10"

if ($domain -eq $NULL -or $aRecord -eq $NULL) 
{ 
    "Invalid Parameters." 
    "Syntax is : createPrimary.ps1 <domain name> <A record>" 
}

else
{
    "Attempting to add and configure Forward Lookup Zone for $domain"
    dnscmd localhost /ZoneAdd $domain /Primary /file $zoneFile /a admin@storagecraft.com 
    dnscmd localhost /RecordAdd $domain "@" NS dns1.storagecraft.com 
    dnscmd localhost /RecordAdd $domain "@" NS dns2.storagecraft.com 
    dnscmd localhost /RecordAdd $domain "@" NS dns3.storagecraft.com 
    dnscmd localhost /RecordAdd $domain "@" NS dns4.storagecraft.com
    dnscmd localhost /RecordDelete $domain "@" NS stc-dc1.stc.local /f  
    dnscmd localhost /RecordAdd $domain "@" A $aRecord 
    dnscmd localhost /RecordAdd $domain www A $aRecord 
    dnscmd localhost /RecordAdd $domain "@" SOA dns1.storagecraft.com admin.storagecraft.com 10 900 600 86400 3600
    dnscmd localhost /zoneresetsecondaries $domain /securelist $secondaryServer /Notify   
}