# createPrimaryBulk.ps1
# Written by Ethan Dodge (ethan.dodge@storagecraft.com) on 3/12/2014 for use at StorageCraft Technology Corporation
# This script takes 2 parameters, a text file and an A record, and creates a Forward Lookup Zone on the localhost for every domain in the text file with that A record
# It's sister script, createSecondaryBulk.ps1, then needs to be run on all DNS servers to which the zone should be copied as a secondary zone

$file=$args[0]
$aRecord=$args[1]
$secondaryServer="10.1.3.18"
$thirdiaryServer="10.1.3.19"

if ($file -eq $NULL -or $aRecord -eq $NULL) 
{ 
    "Invalid Parameters." 
    "Syntax is : createPrimaryBulk.ps1 <file> <A record>" 
}

else
{
    $domainList = Get-Content $file

    foreach ($element in $domainList)
    {
        $domain = $element
        $zoneFile=$domain + ".dns"

        "===============BEGIN $domain=============="

        "Attempting to add and configure Forward Lookup Zone for $domain"
        dnscmd localhost /ZoneAdd $domain /Primary /file $zoneFile /a admin@storagecraft.com 
        dnscmd localhost /RecordAdd $domain "@" NS dns1.storagecraft.com 
        dnscmd localhost /RecordAdd $domain "@" NS dns2.storagecraft.com 
        dnscmd localhost /RecordAdd $domain "@" NS dns3.storagecraft.com 
        dnscmd localhost /RecordAdd $domain "@" NS dns4.storagecraft.com
        dnscmd localhost /RecordDelete $domain "@" NS stc-dc1.stc.local /f  
        dnscmd localhost /RecordAdd $domain "@" A $aRecord 
        dnscmd localhost /RecordAdd $domain www A $aRecord 
        dnscmd localhost /RecordAdd $domain "@" SOA dns1.storagecraft.com admin.storagecraft.com 10 900 600 86400 3600
        dnscmd localhost /zoneresetsecondaries $domain /securelist $secondaryServer /Notify 
	dnscmd localhost /zoneresetsecondaries $domain /securelist $thirdiaryServer /Notify

        "===============END $domain=============="
    }
      
}