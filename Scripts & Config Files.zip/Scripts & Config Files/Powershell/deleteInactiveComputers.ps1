﻿# Import AD module if not already
If (!(Get-module ActiveDirectory )) {
    Import-Module ActiveDirectory
}

# All disabled computer accounts that have been inactive for 90 days
cls
$disabledOU = "OU=DisabledComputers,OU=Computers,OU=StorageCraft,DC=stc,DC=local"
Search-ADAccount -SearchBase $disabledOU -AccountInactive -TimeSpan 90.00:00:00 | ForEach-Object { Remove-ADObject -Identity "$_" -Recursive -Confirm:$False }