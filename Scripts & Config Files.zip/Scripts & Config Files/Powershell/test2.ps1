﻿$ou = Get-ADComputer -SearchBase "OU=DisabledComputers,OU=Computers,OU=StorageCraft,DC=stc,DC=local" -Filter *
foreach ($computer in $ou) {
    $DN = $computer.DistinguishedName
    Get-ADGroup -LDAPFilter "(member=$DN)" | foreach-object {
        if ($_.name -ne "Domain Computers") {remove-adgroupmember -identity $_.name -member $DN} 
    }
}