
# GetGroupMember returns a list of names of users within a group.
#
# Example: Return all members of the group "IT-Users" (without a space)
# .\GetGroupMembers.ps1 -group IT-Users
#
# Example: Return all members of the group "Domain Admins" (with a space)
# .\GetGroupMembers.ps1 -group "Domain Admins"
#
# results are sorted alphabetically

param($group)
Get-ADGroupMember $group -recursive | sort -property name | format-wide