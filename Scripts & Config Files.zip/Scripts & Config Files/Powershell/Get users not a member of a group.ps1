﻿Get-ADUser -filter {enabled -eq $true} -SearchBase "OU=Site0001,OU=Pharmacies,OU=Users,OU=UpWell,DC=UPWELL,DC=COM" -Properties * | ForEach-Object {
    $name = $_.name
    $department = $_.department
    $OU = ($_.distinguishedname -split '[,\=]')[3]
    $memberof = $_.memberof
    $title = $_.title
    $office = $_.physicaldeliveryofficename

    if (!($memberof -match "mdm-users")) {
        Write-Output "$OU,$office,$department,$name,$title"
    }
}