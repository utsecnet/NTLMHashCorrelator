﻿$dictionary = Get-Content C:\Users\rjohnson\Documents\passwordAuditing\rockyou.txt | ConvertTo-NTHashDictionary
$domain = “dc=upwell,dc=com”
$dc = “pslwsdc01”
get-adreplaccount -all -server $dc -namingcontext $domain |test-passwordquality -weakpasswordhashes $dictionary -showplaintextpasswords -includedisabledaccounts >output.txt