﻿$ADServer = "pslwsdc01.upwell.com"
$top = "OU=Users,OU=UpWell,DC=UPWELL,DC=COM"
$allOUs = Get-ADOrganizationalUnit -Server $ADServer -SearchBase $top -Filter 'Name -like "*Corporate*" -OR Name -like "*Pharmacies*"'
$allEmployees = $allOUs | ForEach-Object { Get-ADUser -Server $ADServer -Filter {emailaddress -like "*@*"} -SearchBase $_ -Properties manager }
$managers = New-Object 'System.Collections.Generic.List[System.Object]'

$allEmployees | ForEach-Object {
    
    # This will only return a list of manager's first and last names
    $manager = ($_.manager -split '[,\=]')[1]
    $managers.Add($manager)
}

$managers | Sort -Unique
