﻿$managers = (Get-ADUser -filter * -SearchBase "OU=Corporate,OU=Users,OU=UpWell,DC=UPWELL,DC=COM" -Properties *).Manager | Sort-Object | get-unique
foreach ($user in $managers) {
    
    $fullname = (get-aduser -filter 'distinguishedname -eq $user').Name
    #$email = (get-aduser -filter 'distinguishedname -eq $user').userprincipalName
    $phone = (get-aduser -filter 'distinguishedname -eq $user' -Properties officephone).officephone
    
    
    
    #$managerNames = ($user -split '[=,]')[1]
    
    write-output "$fullname, $phone"
}