﻿
write-host "#################################################################################################################################"
write-host "#                                                                                                                               #"
write-host "# Groups that are a member of other groups                                                                                      #"
write-host "#                                                                                                                               #"
write-host "#################################################################################################################################"

Get-ADGroup -filter * -SearchBase "OU=DistributionGroups,OU=Groups,OU=StorageCraft,DC=stc,DC=local" -Properties * | ? {($_.distinguishedname -notlike "*ShadowGroups-DLs*" ) -and ($_.memberof -like "*")} | ForEach-Object {
    Write-Host $_.name
    Write-Host " \_ " $_.distinguishedname
    Write-Host " | "
    Write-Host " \_ Member of: "
    foreach ( $member in $_.memberof ) {
        Write-Host "   \_ "$member
    }
    Write-Host ""
    Write-Host ""
    Write-Host ""
}

write-host "#################################################################################################################################"
write-host "#                                                                                                                               #"
write-host "# Groups that have "send unauthenticated"                                                                                       #"
write-host "#                                                                                                                               #"
write-host "#################################################################################################################################"
$session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri http://stc-exch.stc.local/PowerShell -Authentication Kerberos -Name stc-exch
[void] (Import-PSSession $session -AllowClobber)

Get-DistributionGroup | ? {$_.RequireSenderAuthenticationEnabled -eq $false} | select Name,PrimarySMTPAddress


Remove-PSSession $session










<#

Group Name
 - DN

 - Memberof
 - - group1
 - - group2


Group Name
 - DN

 - Memberof
 - - group1
 - - group2




#>