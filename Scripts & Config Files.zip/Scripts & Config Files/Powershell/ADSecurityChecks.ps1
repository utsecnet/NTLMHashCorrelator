﻿###########
# Functions
###########

function userDetails ($string,$number) {
    $a = @{Expression={$_.name};Label="$string"}
    $value = Get-ADUser -Server $server -Filter {useraccountcontrol -band $number} -SearchBase "$extraValue" | ? {$_.enabled -eq $true} | Sort-Object name | ft $a
    return $value
}

###########
# Variables
###########

# Include PS environment (used to get the AD domain name)
.\ADEnvironment.ps1

# Domain name
$domainName = (Get-ADRootDSE).defaultNamingContext

# Set the searchBase to the Employees OU only for finding accounts with non-expiring passwords
$searchBase = "OU=Employees,OU=Users,OU=StorageCraft,$domainName"

$uncPath = "\\domain.com\sysvol"

$server = "stc-ut-dc2"

#########
# Action!
#########

try {

    # Look for stored credentials in GPP.  Returns path to any file that contains "cpassword"
    Get-ChildItem -Path $uncPath -recurse | Select-String -pattern "cpassword" | group path | select name

    $passwordNeverExpire = userDetails "Users with passwords set to never expire" "65536"

    # Set the searchBase back to top level
    $extraValue = $domainName

    $passwordNotRequired = userDetails "Users that do not require a password" "32"
    $passwordsAreReversible = userDetails "Users with password stored using reversible encryption" "128"
    $usersTrustedForKerberosDeligation = userDetails "Users that are trusted with Kerberos Deligation" "524288"
    $usersDontRequirePreAuth = userDetails "Users that do not require pre-authentication" "4194304"
    $passwordsDESEncrypted = userDetails "Users whose passwords are encrypted with DES" "2097152"

    $passwordNeverExpire
    $passwordNotRequired 
    $passwordsAreReversible
    $usersTrustedForKerberosDeligation
    $usersDontRequirePreAuth
    $passwordsDESEncrypted


}
catch {
    $scriptError = $Error[0]
}

