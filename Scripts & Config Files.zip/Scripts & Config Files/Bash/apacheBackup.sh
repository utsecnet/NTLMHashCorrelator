#!/bin/bash

#####################################################
# Backup apache conf files to STC-Backup/stc-rproxy #
#####################################################

# Variables
un=<username>
pw=<password>
datestamp=$(date +%Y-%m-%d)
serverName=stc-backup
localDir=/etc/httpd
localMount=/mnt/backupServer
remoteDir=//10.1.10.17/Large/S-UT-RProxy1
sync=off

# Do not edit
fullDestination=$localMount/config_files/$datestamp

# Lock file exists, so exit
if [ -a /root/lock ]; then
        echo "     Lock file exists, exiting..."
        exit
fi

# attempt to mount Windows shared drive to mount point
echo "Mounting remote file system."
if mount -t cifs $remoteDir $localMount -o username=$un,password=$pw,domain=$serverName; then
    echo "      Remote file system successfully mounted."
    touch /root/lock
else
    echo "      There was an error mounting remote file system.  Exiting..."
    exit
fi

# sync conf files
#/usr/bin/rsync -av --files-from=/usr/local/bin/files $localDir $localMount
/usr/bin/rsync -av $localDir/conf* $localMount
/usr/bin/rsync -av $localDir/ssl/* $localMount/ssl
mkdir -p $fullDestination
#/usr/bin/rsync -av --files-from=/usr/local/bin/files $localDir $fullDestination
/usr/bin/rsync -av $localDir/conf* $fullDestination

#move rotated log files
mkdir -p $localMount/logs
mv $localDir/logs/*2012* $localMount/logs
mv $localDir/logs/*2013* $localMount/logs
mv $localDir/logs/*2014* $localMount/logs
mv $localDir/logs/*2015* $localMount/logs
mv $localDir/logs/*2016* $localMount/logs
mv $localDir/logs/*2017* $localMount/logs
mv $localDir/logs/*2018* $localMount/logs
mv $localDir/logs/*2019* $localMount/logs

#unmount mount point and remove the /bak dir from system
echo "  Network drive will now be unmounted."
rm -f /root/lock
umount $localMount
exit
