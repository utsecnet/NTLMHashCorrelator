#!/bin/bash
# CentPostInstallScript
# Written by Rich Johnson
# 2015-08-28
# Version 1.2 Last updated 6/3/2015
# Post CentOS 7 deply script.

# Change log
# Version 1.2
#   * Added local repositories to download packages from stc-linuxrepo 
#     (10.1.10.10).
#   * Perform yum cleanup
#   * Additional banner /etc/issue.net
#   * Allow any tcp/udp from Nessus in iptables

# Version 1.1
#   * Ability to use multiple domains
#   * If the ext.local domain is selected, assume static IP and ask for
#     network parameters.
#   * Configure eth interface properties to be static if external domain
#   * Shorten the question answer sections to a single line of code
#   * Installed VMware tools in the template image.  This is so I know what the
#     IP address is of the new VM that gets created, so I can SSH into the VM
#     without having to console in and get the IP address first.
#   * Build the /etc/sysconfig/iptables default firewall configuration.
#   * Added status updates for those times when the script looks like it's not 
#     doing anything.
#   * Added package policycoreutils-python,setroubleshoot,setroubleshoot-server
#     to get semanage and other SELinux manangement packages.

# TODO - Assign variables that are particular to StorageCraft's environment
#        at the top, so other companies could use this without having to dig 
#        through the whole script.
# TODO - patchPolicy
# TODO - Verify disableWirelessDrivers works correctly

#########################################
# Function - main
#########################################
function main {

# Call Functions
  # Host System Configuration
    changeHostName
    networkConfig
    configureAliases
    configurePrompt

  # Party Software Installation & Configuration
    configureRepos
    installPackages
    # installVMwareTools Should already be installed from the default VMware Server Template
    configureNTP
    configureSNMP
    changeVIM

  # Security Policies
    configureIptables
    configureServices
    systemIdentification
    secureRoot
    # disableWirelessDrivers
    secureSysctl
    joinAD
    sshPolicy
    # confidureSudo
}

#########################################
# Function - changeHostName
#########################################
function changeHostName {

read -e -p "Enter new Hostname for this server: " NEWHOSTNAME
read -e -p "Enter Domain Name: " -i "stc.local" NEWDOMAINNAME
read -e -p "FQDN to be $NEWHOSTNAME.$NEWDOMAINNAME? [y] [n]: " ANSWER
while [[ $ANSWER != [Yy] ]]
do
  read -e -p "Enter new Hostname for this server: " NEWHOSTNAME
  read -e -p "Enter Domain Name: " -i "stc.local" NEWDOMAINNAME
  read -e -p "FQDN to be $NEWHOSTNAME.$NEWDOMAINNAME? [y] [n]: " ANSWER
done

echo "Setting hostname..."
hostnamectl set-hostname $NEWHOSTNAME
mv /etc/hosts /etc/hosts.BAK
echo -e "127.0.0.1      $NEWHOSTNAME $NEWHOSTNAME.$NEWDOMAINNAME\n::1           $NEWHOSTNAME $NEWHOSTNAME.$NEWDOMAINNAME" >> /etc/hosts
echo DHCP_HOSTNAME=$NEWHOSTNAME >> /etc/sysconfig/network-scripts/ifcfg-ens32
}

#########################################
# Function - networkConfig
#########################################
function networkConfig {

hwAddress=`cat /sys/class/net/ens32/address`
nicProperties=/etc/sysconfig/network-scripts/ifcfg-ens32

sed --in-place '/HWADDR/d' $nicProperties
sed --in-place '/ONBOOT/d' $nicProperties
echo -e "HWADDR=\"$hwAddress\"" >> $nicProperties
echo -e "ONBOOT=\"yes\"" >> $nicProperties

if [ "$NEWDOMAINNAME" = 'ext.local' ]; then
  read -e -p "Enter new ip address: " IPADDRESS
  read -e -p "Enter new subnet mask: " SUBNETMASK
  read -e -p "Enter new gateway: " GATEWAY
  read -e -p "IP: $IPADDRESS, SNM: $SUBNETMASK, GW: $GATEWAY, correct? [y] [n]: " ANSWER2

  while [[ $ANSWER2 != [Yy] ]]
  do
    read -e -p "Enter new ip address: " IPADDRESS
    read -e -p "Enter new subnet mask: " SUBNETMASK
    read -e -p "Enter new gateway: " GATEWAY
    read -e -p "IP: $IPADDRESS, SNM: $SUBNETMASK, GW: $GATEWAY, correct? [y] [n]: " ANSWER2
  done

  echo "Configuring network..."
  sed --in-place '/BOOTPROTO/d' $nicProperties
  sed --in-place '/DHCP_HOSTNAME/d' $nicProperties
  echo -e "NM_CONTROLLED=\"no\"" >> $nicProperties
  echo -e "BOOTPROTO=\"static\"" >> $nicProperties
  echo -e "IPADDR=\"$IPADDRESS\"" >> $nicProperties
  echo -e "NETMASK=\"$SUBNETMASK\"" >> $nicProperties
  echo -e "GATEWAY=\"$GATEWAY\"" >> $nicProperties

  # Build /etc/resolv.conf
  resolv=/etc/resolv.conf
  mv $resolv $resolv.BAK
  echo domain ext.local >> $resolv
  echo search ext.local >> $resolv
  echo nameserver 10.1.10.14 >> $resolv

  echo "Restarting network..."
  systemctl restart network
else
  systemctl restart network
fi

  # TODO - May have to build resolv.conf file, if DNS servers do not get added 
  # on domain join
}

#########################################
# Function - configureAliases
#########################################
function configureAliases {

echo "Configuring aliases..."
file=/etc/bashrc
cat >> $file <<EOF
# Aliases
alias ll='ls -lha'
alias top='htop'
alias ..='cd ..'
alias vi='vim'
alias df='df -h'
alias ifconfig='ip addr'
alias visudo='EDITOR=vim visudo'

EOF
}

#########################################
# Function - configurePrompt
#########################################
function configurePrompt {

echo "Configuring prompt..."
file=/etc/bashrc

cat >> $file << 'EOF'
# Bash Prompt
# Reset
Color_Off="\[\033[0m\]"       # Text Reset

# Regular Colors
Black="\[\033[0;30m\]"        # Black
Red="\[\033[0;31m\]"          # Red
Green="\[\033[0;32m\]"        # Green
Yellow="\[\033[0;33m\]"       # Yellow
Blue="\[\033[0;34m\]"         # Blue
Purple="\[\033[0;35m\]"       # Purple
Cyan="\[\033[0;36m\]"         # Cyan
White="\[\033[0;37m\]"        # White

# Bold
BBlack="\[\033[1;30m\]"       # Black
BRed="\[\033[1;31m\]"         # Red
BGreen="\[\033[1;32m\]"       # Green
BYellow="\[\033[1;33m\]"      # Yellow
BBlue="\[\033[1;34m\]"        # Blue
BPurple="\[\033[1;35m\]"      # Purple
BCyan="\[\033[1;36m\]"        # Cyan
BWhite="\[\033[1;37m\]"       # White

# Underline
UBlack="\[\033[4;30m\]"       # Black
URed="\[\033[4;31m\]"         # Red
UGreen="\[\033[4;32m\]"       # Green
UYellow="\[\033[4;33m\]"      # Yellow
UBlue="\[\033[4;34m\]"        # Blue
UPurple="\[\033[4;35m\]"      # Purple
UCyan="\[\033[4;36m\]"        # Cyan
UWhite="\[\033[4;37m\]"       # White

# Background
On_Black="\[\033[40m\]"       # Black
On_Red="\[\033[41m\]"         # Red
On_Green="\[\033[42m\]"       # Green
On_Yellow="\[\033[43m\]"      # Yellow
On_Blue="\[\033[44m\]"        # Blue
On_Purple="\[\033[45m\]"      # Purple
On_Cyan="\[\033[46m\]"        # Cyan
On_White="\[\033[47m\]"       # White

# High Intensty
IBlack="\[\033[0;90m\]"       # Black
IRed="\[\033[0;91m\]"         # Red
IGreen="\[\033[0;92m\]"       # Green
IYellow="\[\033[0;93m\]"      # Yellow
IBlue="\[\033[0;94m\]"        # Blue
IPurple="\[\033[0;95m\]"      # Purple
ICyan="\[\033[0;96m\]"        # Cyan
IWhite="\[\033[0;97m\]"       # White

# Bold High Intensty
BIBlack="\[\033[1;90m\]"      # Black
BIRed="\[\033[1;91m\]"        # Red
BIGreen="\[\033[1;92m\]"      # Green
BIYellow="\[\033[1;93m\]"     # Yellow
BIBlue="\[\033[1;94m\]"       # Blue
BIPurple="\[\033[1;95m\]"     # Purple
BICyan="\[\033[1;96m\]"       # Cyan
BIWhite="\[\033[1;97m\]"      # White

# High Intensty backgrounds
On_IBlack="\[\033[0;100m\]"   # Black
On_IRed="\[\033[0;101m\]"     # Red
On_IGreen="\[\033[0;102m\]"   # Green
On_IYellow="\[\033[0;103m\]"  # Yellow
On_IBlue="\[\033[0;104m\]"    # Blue
On_IPurple="\[\033[10;95m\]"  # Purple
On_ICyan="\[\033[0;106m\]"    # Cyan
On_IWhite="\[\033[0;107m\]"   # White

if [[ "$(id -u)" -eq 0 || $USER = *.a || $USER = admin ]]; then
  Cust_color="\[\033[0;31m\]"
  Cust_char="#"
else
  Cust_color="\[\033[0;32m\]"
  Cust_char="$"
fi

export PS1="\n$Cyan\d \t $BBlack[$Cust_color\u$BBlue@\h$BBlack:$White${SSH_TTY:-o} $Green+${SHLVL}$BBlack] $BWhite\w $BBlack\$(/bin/ls -lah | /bin/grep -m 1 total | /bin/sed 's/total //')b$Color_Off \n\[$Cust_char \] "

EOF
}

#########################################
# Function - configureRepos
#########################################
function configureRepos {

echo "Configuring repos..."

#osVersion=`rpm -qa \*-release | grep -Ei "oracle|redhat|centos" | cut -d"-" -f3`
#unameCommand=`uname -r`
#
#if [[ $unameCommand = *86_64* ]] ; then
#        arch=x86_64
#else
#        arch=i386
#fi
#
# Instal EPEL Repo
#if [[ $osVersion = 7 ]] ; then
#       if [[ $arch = x86_64 ]] ; then
#               echo "Will download the 7 + 64"
#       else
#               echo "Will download the 7 + 86"
#       fi
#elif [[ $osVersion = 6 ]] ; then
#       if [[ $arch = x86_64 ]] ; then
#               echo "Will download the 6 + 64"
#       else
#               echo "Will download the 6 + 86"
#       fi
#elif [[ $osVersion = 5 ]] ; then
#       if [[ $arch = x86_64 ]] ; then
#               echo "Will download the 5 + 64"
#       else
#               echo "Will download the 5 + 86"
#       fi
#else
#       echo "You are using a version of CentOS that is just too damn old!"
#fi
#yum -y install epel-release

repo1=/etc/yum.repos.d/centos.repo
repo2=/etc/yum.repos.d/epel.repo

# Remove all the old repos
rm -f /etc/yum.repos.d/*.repo

cat >> $repo1 << 'EOF'
[base]
name=CentOS-$releasever - Base
baseurl=http://10.1.10.10/repodata/LinuxDistros/centos/$releasever/os/$basearch/
gpgcheck=1
gpgkey=file:/etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
protect=1
priority=1
enabled=1
[updates]
name=CentOS-$releasever - Updates
baseurl=http://10.1.10.10/repodata/LinuxDistros/centos/$releasever/updates/$basearch/
gpgcheck=1
gpgkey=file:/etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
protect=1
priority=1
enabled=1
[extras]
name=CentOS-$releasever - Extras
baseurl=http://10.1.10.10/repodata/LinuxDistros/centos/$releasever/extras/$basearch/
gpgcheck=1
gpgkey=file:/etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
protect=1
priority=1
enabled=0
[centosplus]
name=CentOS-$releasever - Plus
baseurl=http://10.1.10.10/repodata/LinuxDistros/centos/$releasever/centosplus/$basearch/
exclude=kernel*
gpgcheck=1
enabled=0
gpgkey=file:/etc/pki/rpm-gpg/RPM-GPG-KEY-CentOS-7
protect=0
priority=1
EOF

cat >> $repo2 << 'EOF'
[epel]
name=EPEL Repository
baseurl=http://10.1.10.10/repodata/LinuxDistros/epel/$releasever/$basearch/
enabled=1
gpgcheck=0
EOF

}

rm -f /etc/yum.repos.d/CentOS-*

#########################################
# Function - installPackages
#########################################
function installPackages {

echo "Installing packages..."
yum clean all && yum clean metadata && yum clean dbcache && yum makecache
yum -y install htop vim iptables-services ntp net-snmp-utils net-snmp wget policycoreutils-python setroubleshoot setroubleshoot-server && yum update -y

}

#########################################
# Function - installVMwareTools
#########################################
function installVMwareTools {

echo "Installing VMWare Tools..."
mkdir /mnt/cdrom
if mount /dev/cdrom /mnt/cdrom; then
        cp /mnt/cdrom/VMwareTools-*.tar.gz /tmp
        umount /mnt/cdrom
        tar -zxf /tmp/VMwareTools-*.tar.gz -C /tmp
        cd /
        ./tmp/vmware-tools-distrib/vmware-install.pl --default
        rm -f /tmp/VMwareTools-*.tar.gz
        rm -rf /tmp/vmware-tools-distrib
else
        echo "We could not mount the vmware tools."

fi
}

#########################################
# Function - configureIptables
#########################################
function configureIptables {

echo "Configuring iptables..."
# force iptables to log to its own log, and not write to /var/log/messages
cat > /etc/rsyslog.d/iptables.conf <<EOF
:msg, startswith, "FW-REJECT " -/var/log/iptables
& ~
EOF
mkdir /var/log/iptables_rotated

# rotate iptables log keeping 7 days worth
cat > /etc/logrotate.d/iptables <<EOF
/var/log/iptables
{
        rotate 7
   daily
   missingok
   notifempty
   delaycompress
   compress
   postrotate
   olddir /var/log/iptables_rotated/
   endscript
}
EOF

# disable firewalld and enable iptables
systemctl disable firewalld
systemctl enable iptables

# Generate the iptables config file
if [ "$NEWDOMAINNAME" = 'stc.local' ]; then
cat > /etc/sysconfig/iptables <<EOF

*filter
:INPUT ACCEPT [0:0]
:FORWARD ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
-A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
-A INPUT -p icmp -j ACCEPT
-A INPUT -i lo -j ACCEPT
-A INPUT -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG NONE -j REJECT
-A INPUT -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG FIN,SYN,RST,PSH,ACK,URG -j REJECT
-A INPUT -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG FIN,PSH,URG -j REJECT
-A INPUT -p tcp --tcp-flags FIN,SYN FIN,SYN -j REJECT
-A INPUT -p tcp --tcp-flags SYN,RST SYN,RST -j REJECT
-A INPUT -p tcp --tcp-flags FIN,RST FIN,RST -j REJECT
-A INPUT -p tcp --tcp-flags FIN,ACK FIN -j REJECT
-A INPUT -p tcp --tcp-flags PSH,ACK PSH -j REJECT
-A INPUT -p tcp --tcp-flags ACK,URG URG -j REJECT

# Add Implicit rules here

-A INPUT -p tcp -s 10.1.2.0/24 -j ACCEPT -m comment --comment "From IT -- Any TCP"
-A INPUT -p udp -s 10.1.2.0/24 -j ACCEPT -m comment --comment "From IT -- Any UDP"
-A INPUT -p tcp -s 172.16.23.0/24 -j ACCEPT -m comment --comment "From IE IT -- Any TCP"
-A INPUT -p udp -s 172.16.23.0/24 -j ACCEPT -m comment --comment "From IE IT -- Any UDP"
-A INPUT -p tcp -s 10.1.0.4 -j ACCEPT -m comment --comment "From Nagios -- Any TCP"
-A INPUT -p udp -s 10.1.0.4 -j ACCEPT -m comment --comment "From Nagios -- Any UDP"
-A INPUT -p tcp -s 10.1.10.18 -j ACCEPT -m comment --comment "From Nessus -- Any TCP"
-A INPUT -p udp -s 10.1.10.18 -j ACCEPT -m comment --comment "From Nessus -- Any UDP"
-A INPUT -p tcp -s 10.1.0.152 --dport 22 -j ACCEPT -m comment --comment "From Spiceworks3 -- SSH"
-A INPUT -p udp --dport 137:138 -j DROP -m comment --comment "Drop chatty UDP broadcasts"
-A INPUT -p udp --dport 50799 -j DROP -m comment --comment "Drop chatty UDP broadcasts"
-A INPUT -p udp --dport 67:68 -j DROP -m comment --comment "Drop chatty UDP broadcasts"

# Add explicit rules here

# Log dropped and reject the rest

-A INPUT -j LOG --log-prefix "FW-REJECT "
-A INPUT -j REJECT --reject-with icmp-host-prohibited
COMMIT

EOF

fi

if [ "$NEWDOMAINNAME" = 'ext.local' ]; then
cat > /etc/sysconfig/iptables <<EOF

*filter
:INPUT ACCEPT [0:0]
:FORWARD ACCEPT [0:0]
:OUTPUT ACCEPT [0:0]
-A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
-A INPUT -p icmp -j ACCEPT
-A INPUT -i lo -j ACCEPT
-A INPUT -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG NONE -j REJECT
-A INPUT -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG FIN,SYN,RST,PSH,ACK,URG -j REJECT
-A INPUT -p tcp --tcp-flags FIN,SYN,RST,PSH,ACK,URG FIN,PSH,URG -j REJECT
-A INPUT -p tcp --tcp-flags FIN,SYN FIN,SYN -j REJECT
-A INPUT -p tcp --tcp-flags SYN,RST SYN,RST -j REJECT
-A INPUT -p tcp --tcp-flags FIN,RST FIN,RST -j REJECT
-A INPUT -p tcp --tcp-flags FIN,ACK FIN -j REJECT
-A INPUT -p tcp --tcp-flags PSH,ACK PSH -j REJECT
-A INPUT -p tcp --tcp-flags ACK,URG URG -j REJECT

# Add Implicit rules here

-A INPUT -p tcp -s 10.1.2.0/24 -j ACCEPT -m comment --comment "From IT -- Any TCP"
-A INPUT -p udp -s 10.1.2.0/24 -j ACCEPT -m comment --comment "From IT -- Any UDP"
-A INPUT -p tcp -s 172.16.23.0/24 -j ACCEPT -m comment --comment "From IE IT -- Any TCP"
-A INPUT -p udp -s 172.16.23.0/24 -j ACCEPT -m comment --comment "From IE IT -- Any UDP"
-A INPUT -p tcp -s 10.1.0.4 -j ACCEPT -m comment --comment "From Nagios -- Any TCP"
-A INPUT -p udp -s 10.1.0.4 -j ACCEPT -m comment --comment "From Nagios -- Any UDP"
-A INPUT -p tcp -s 10.1.10.18 -j ACCEPT -m comment --comment "From Nessus -- Any TCP"
-A INPUT -p udp -s 10.1.10.18 -j ACCEPT -m comment --comment "From Nessus -- Any UDP"
-A INPUT -p tcp -s 10.1.10.12 --dport 22 -j ACCEPT -m comment --comment "From Spiceworks2 -- SSH"
-A INPUT -p udp --dport 137:138 -j DROP -m comment --comment "Drop chatty UDP broadcasts"
-A INPUT -p udp --dport 50799 -j DROP -m comment --comment "Drop chatty UDP broadcasts"
-A INPUT -p udp --dport 67:68 -j DROP -m comment --comment "Drop chatty UDP broadcasts"

# Add explicit rules here

# Log dropped and reject the rest

-A INPUT -j LOG --log-prefix "FW-REJECT "
-A INPUT -j REJECT --reject-with icmp-host-prohibited
COMMIT

EOF

fi

systemctl restart iptables.service
}

#########################################
# Function - configureNTP
#########################################
function configureNTP {

echo "Configuring NTP..."
if [ "$NEWDOMAINNAME" = 'stc.local' ]; then
  timeServer=10.1.0.9
elif [ "$NEWDOMAINNAME" = 'ext.local' ]; then
  timeServer=10.1.10.14
else
  echo "ERROR! NTP must be configured manually."
fi

echo $timeServer

localtime=/etc/localtime
ntpConf=/etc/ntp.conf
sed --in-place '/server/d' $ntpConf
sed --in-place '/#/d' $ntpConf
sed --in-place '/^$/d' $ntpConf
sed --in-place '/./!d' $ntpConf
echo -e "\nserver $timeServer" >> $ntpConf

mv $localtime $localtime.BAK
cp /usr/share/zoneinfo/America/Denver $localtime

systemctl start ntpd.service
}

#########################################
# Function - configureSNMP
#########################################
function configureSNMP {

echo "Configuring SNMP..."
snmpConf=/etc/snmp/snmpd.conf
mv $snmpConf $snmpConf.BAK

cat > $snmpConf <<EOF
rocommunity Protectedbyshadow 10.1.0.4
rocommunity Protectedbyshadow 127.0.0.1
syslocation "ESX Prod Cluster"
syscontact helpdesk@storagecraft.com
EOF

systemctl start snmpd.service
}

#########################################
# Function - configureServices
#########################################
function configureServices {

echo "Configuring services..."
## list all services
# systemctl list-unit-files

## list all enabled auto-start services
# systemctl list-unit-files | grep enabled | sort

# Autostart services
systemctl enable snmpd.service
systemctl enable ntpd.service

# Disable autostart of services
systemctl disable avahi-daemon.service
}

#########################################
# Function - joinAD
#########################################
function joinAD {

echo "Joining AD..."
if [ "$NEWDOMAINNAME" = 'stc.local' ]; then
  ADconfig=centrify-suite.cfg
elif [ "$NEWDOMAINNAME" = 'ext.local' ]; then
  ADconfig=centrify-suite2.cfg
else
  echo "ERROR!"
fi

#create A and PTR records on the DNS server
addns -U -m

/root/Documents/install-express.sh --express --suite-config /root/Documents/$ADconfig

sed -i 's/^PASSWD.*/PASSWD=password/' /root/Documents/centrify-suite.cfg
sed -i 's/^PASSWD.*/PASSWD=password/' /root/Documents/centrify-suite2.cfg
}

#########################################
# Function - sshPolicy
#########################################
function sshPolicy {

echo "Configuring SSH policy..."
sshConf1=/etc/ssh/sshd_config
sshConf2=/etc/centrifydc/ssh/sshd_config
banner1=/etc/ssh/sshd-banner
banner2=/etc/issue
banner3=/etc/issue.net

#Deny root logins
sed --in-place '/PermitRootLogin yes/d' $sshConf1
sed --in-place '/PermitRootLogin yes/d' $sshConf2
echo "PermitRootLogin no" >> $sshConf1
echo "PermitRootLogin no" >> $sshConf2

#Set banner
cat > $banner1 <<EOF

###############################################################################
#                                                                             #
# This computer system may only be used by authorized StorageCraft employees  #
# and contractors.  By using this system, you agree to the following:         #
# --------------------------------------------------------------------------- #
# *  comply with StorageCraft policies and procedures in using this system.   #
# *  StorageCraft may monitor, log and record activities on this system.      #
# *  Unauthorized or improper use may result in disciplinary action.          #
# *  The computer system is owned and operated by StorageCraft and you have   #
#    no right of privacy.  Communications made through this system and data   #
#    stored on the system are not private and StorageCraft may view, disclose #
#    or use them for any authorized or lawful purpose.                        #
# --------------------------------------------------------------------------- #
# LOG OFF IMMEDIATELY if you do not agree to these conditions.  If you have   #
# questions about these conditions, please contact Human Resources or the     #
# IT Manager.  If you are not an authorized StorageCraft employee or          #
# contractor, you have no right to access this computer system and any such   #
# access is a violation of law for which you are subject to civil and/or      #
# criminal prosecution.                                                       #
#                                                                             #
###############################################################################

EOF

rm -f $banner2
rm -f $banner3
cp $banner1 $banner2
cp $banner1 $banner3

echo "Banner $banner1" >> $sshConf1
echo "Banner $banner1" >> $sshConf2
systemctl restart sshd.service

}

#########################################
# Function - changeVIM
#########################################
function changeVIM {

echo "Configuring VIM..."
vimrc=/etc/vimrc

mv $vimrc $vimrc.BAK
cat > $vimrc <<EOF

set nocompatible            " Use Vim defaults (much better!)

if v:lang =~ "utf8$" || v:lang =~ "UTF-8$"
   set fileencodings=ucs-bom,utf-8,latin1
endif

" Only do this part when compiled with support for autocommands
if has("autocmd")
  augroup redhat
  autocmd!
  " In text files, always limit the width of text to 78 characters
  " autocmd BufRead *.txt set tw=78
  " When editing a file, always jump to the last cursor position
  autocmd BufReadPost *
  \ if line("'\"") > 0 && line ("'\"") <= line("$") |
  \   exe "normal! g'\"" |
  \ endif
  " don't write swapfile on most commonly used directories for NFS mounts or USB sticks
  autocmd BufNewFile,BufReadPre /media/*,/run/media/*,/mnt/* set directory=~/tmp,/var/tmp,/tmp
  " start with spec file template
  autocmd BufNewFile *.spec 0r /usr/share/vim/vimfiles/template.spec
  augroup END
endif

if has("cscope") && filereadable("/usr/bin/cscope")
   set csprg=/usr/bin/cscope
   set csto=0
   set cst
   set nocsverb
   " add any database in current directory
   if filereadable("cscope.out")
      cs add $PWD/cscope.out
   " else add database pointed to by environment
   elseif $CSCOPE_DB != ""
      cs add $CSCOPE_DB
   endif
   set csverb
endif

" Switch syntax highlighting on, when the terminal has colors
" Also switch on highlighting the last used search pattern.
if &t_Co > 2 || has("gui_running")
  syntax on
  set hlsearch
endif

filetype plugin on

if &term=="xterm"
     set t_Co=8
     set t_Sb=^[[4%dm
     set t_Sf=^[[3%dm
endif

set bs=indent,eol,start   " allow backspacing over everything in insert mode
set ai                             " allow auto indenting
set nobackup                    " do not keep a bakcup file
set viminfo='20,\"50         " read/write a .viminfo file, no more than 50 lines
set copyindent                  " copy the previous indentation on autoindenting
set shiftround            " use multiple of shiftwidth when indenting
                             " with '<' and '>'
set showmatch             " set show matching parenthesis
set ignorecase            " ignore case when searching
set smartcase             " ignore case if search pattern is all lowercase,
                             " case-sensitive otherwise
set smarttab              " insert tabs on the start of a line according to
                             " shiftwidth, not tabstop
set incsearch             " show search matches as you type
set ruler                 " show the cursor position all the time
set colorcolumn=80        " show a verticle line at the possition =##
set number                " show line numbers
set history=1000          " remember more commands and search history
set undolevels=1000       " use many muchos levels of undo
set wildignore=*.swp,*.bak,*.pyc,*.class
set title                 " change the terminal's title
set visualbell            " don't beep
set noerrorbells          " don't beep
set pastetoggle=<F2>      " switch to paste mode using F2 in insert mode
set mouse=a                                  " enable mouse use (scrolling!)

highlight colorcolumn ctermbg=green   " Color of the verticle line
nnoremap ; :                    " use ;w to save instead of :w = faster!
nnoremap j gj                   " dont skip wrapped lines when moving down
nnoremap k gk             " dont skip wrapped lines when moving up
nmap <silent> ,/ :nohlsearch<CR>   " clear search buffer with ,/
cmap w!! q !sudo tee % >/dev/null  " lets you save a file with root priv. if
                                                       " you accedently opened without root
let &guicursor = &guicursor . ",a:blinkon0"    " dont wake up system with a
                                                                        " blinking cursor
EOF
}

#########################################
# Function - systemIdentification
#########################################
function systemIdentification {

sysID=/etc/system_identification

read -e -p "Security Category [L]ow (Default), [M]oderate, [H]igh: " -i "L" category
read -e -p "What environment will this be in? [P]rod, [S]taging, [T]est: " -i "P" envir
read -e -p "What is the purpose for this server? " purpose
read -e -p "What is the relationship of this host to other hosts? " relation

echo "Configuring system identification..."
#TODO data validation
if [ \( $category = "L" \) -o \( $category = "l" \) ]; then
        category=Low
elif [ \( $category = "M" \) -o \( $category = "m" \) ]; then
        category=Moderate
elif [ \( $category = "H" \) -o \( $category = "h" \) ]; then
        category=High
fi

if [ \( $envir = "P" \) -o \( $envir = "p" \) ]; then
        envir=Production
elif [ \( $envir = "S" \) -o \( $envir = "s" \) ]; then
        envir=Staging
elif [ \( $envir = "T" \) -o \( $envir = "t" \) ]; then
        envir=Testing
fi

#TODO data validation and empty answers

cat > $sysID <<EOF
Security Category: $category
Primary Contact: helpdesk@storagecraft.com - (801) 871-2888
Environment: $envir
Purpose: $purpose
Relationship: $relation
EOF
}

#########################################
# Function - secureRoot
#########################################
function secureRoot {

echo "Securing root..."
chmod -R 700 /root
passwd root
}

#########################################
# Function - disableWirelessDrivers
#########################################
function disableWirelessDrivers {

echo "Disabling wireless drivers..."
for i in $(find /lib/modules/`uname -r`/kernel/drivers/net/wireless -name "*.ko" -type f) ; do echo blacklist $i >> /etc/modprobe.d/blacklist-wireless ; done
}

#########################################
# Function - secureSysctl
#########################################
function secureSysctl {

echo "Securing network configurations..."
sysctl=/etc/sysctl.conf

cat > $sysctl <<EOF
# Unless this host serves as a router, do not pass traffic between networks.
net.ipv4.ip_forward = 0

# Unless this host serves as a router, do not act like a network device.
net.ipv4.conf.all.send_redirects = 0

# Unless this host serves as a router, do not act like a network device.
net.ipv4.conf.default.send_redirects = 0

#
net.ipv4.tcp_max_syn_backlog = 1280

# Prevents this host from joining a smurf attack
net.ipv4.icmp_echo_ignore_broadcasts = 1

# Do not allow source routed packets
net.ipv4.conf.all.accept_source_route = 0

# Do not permit outsiders to alter routing tables.
net.ipv4.conf.all.accept_redirects = 0

# Do not allow outsiders to alter routing tables.
net.ipv4.conf.all.secure_redirects = 0

# Log any spoofed, source routed and redirect packets
net.ipv4.conf.all.log_martians = 1

# Log any spoofed, source routed and redirect packets
net.ipv4.conf.all.log_martians = 1

#  Do not allow source routed packets
net.ipv4.conf.default.accept_source_route = 0

#  Do not allow outsiders to alter routing tables.
net.ipv4.conf.default.accept_redirects = 0

# Do not allow outsiders to alter routing tables
net.ipv4.conf.default.secure_redirects = 0

# Protection from bad ICMP error messages
net.ipv4.icmp_ignore_bogus_error_responses = 1

# Enables syncookies for protection against syn flood attacks
net.ipv4.tcp_syncookies = 1

# Enable reverse path filtering
net.ipv4.conf.all.rp_filter = 1

# Enable reverse path filtering
net.ipv4.conf.default.rp_filter = 1
EOF

}

#****************************************
# End of Funtions
#****************************************

main