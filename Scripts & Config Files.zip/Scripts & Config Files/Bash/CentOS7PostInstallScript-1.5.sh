#!/bin/bash
# CentPostInstallScript
# Written by Rich Johnson
# 2015-09-22
# Version 1.2 Last updated 6/3/2015
# Post CentOS 7 deply script.

# Change log
#Version 1.5
#   * Huge overhaul!  Salt now does most of this.  This script now only preps the
#     server to be managed by salt.

#Version 1.4
#   * added packages for nagios-nrpe-plugins
#   * added new function for configuring NRPE client, configureNRPE

#Version 1.3
#   * Added iptables rules for external domain.  It's redundant to stc,
#     but it works
#   * Removed Centrify's SSH server from centrify deploy scripts, so I
#     removed the changes to all the ssh files under /etc/centrifydc/ssh

# Version 1.2
#   * Added local repositories to download packages from stc-linuxrepo
#     (10.1.10.10).
#   * Perform yum cleanup
#   * Additional banner /etc/issue.net
#   * Allow any tcp/udp from Nessus in iptables

# Version 1.1
#   * Ability to use multiple domains
#   * If the ext.local domain is selected, assume static IP and ask for
#     network parameters.
#   * Configure eth interface properties to be static if external domain
#   * Shorten the question answer sections to a single line of code
#   * Installed VMware tools in the template image.  This is so I know what the
#     IP address is of the new VM that gets created, so I can SSH into the VM
#     without having to console in and get the IP address first.
#   * Build the /etc/sysconfig/iptables default firewall configuration.
#   * Added status updates for those times when the script looks like it's not
#     doing anything.
#   * Added package policycoreutils-python,setroubleshoot,setroubleshoot-server
#     to get semanage and other SELinux manangement packages.

# TODO - when you first boot up the new server, the salt-minion daemon start, and sends a
#        key to the master in the form of its IP address.  Need to disable salt-minion
#        in the VM template, and enable it in this script AFTER you conifgure the
#        network.
# TODO - remove the centrify SSH server.  and all the configurations for it.
# TODO - Assign variables that are particular to StorageCraft's environment
#        at the top, so other companies could use this without having to dig
#        through the whole script.
# TODO - patchPolicy
# TODO - Verify disableWirelessDrivers works correctly

#########################################
# Function - main
#########################################
function main {

# Call Functions
    changeHostName
    networkConfig
#    configureSalt
    joinAD
    secureRoot
}

#########################################
# Function - changeHostName
#########################################
function changeHostName {

read -e -p "Enter new Hostname for this server: " NEWHOSTNAME
read -e -p "Enter Domain Name: " -i "stc.local" NEWDOMAINNAME
read -e -p "FQDN to be $NEWHOSTNAME.$NEWDOMAINNAME? [y] [n]: " ANSWER
while [[ $ANSWER != [Yy] ]]
do
  read -e -p "Enter new Hostname for this server: " NEWHOSTNAME
  read -e -p "Enter Domain Name: " -i "stc.local" NEWDOMAINNAME
  read -e -p "FQDN to be $NEWHOSTNAME.$NEWDOMAINNAME? [y] [n]: " ANSWER
done

echo "Setting hostname..."
hostnamectl set-hostname $NEWHOSTNAME
mv /etc/hosts /etc/hosts.BAK
echo -e "127.0.0.1      $NEWHOSTNAME $NEWHOSTNAME.$NEWDOMAINNAME\n::1           $NEWHOSTNAME $NEWHOSTNAME.$NEWDOMAINNAME" >> /etc/hosts
echo DHCP_HOSTNAME=$NEWHOSTNAME >> /etc/sysconfig/network-scripts/ifcfg-ens32
echo $NEWHOSTNAME.$NEWDOMAINNAME > /etc/salt/minion_id
sed -i -e "s/#COMPUTER=my_host_name/COMPUTER=$NEWCOMPUTERNAME/g" /root/Documents/centrify-suite.cfg
sed -i -e "s/#COMPUTER=my_host_name/COMPUTER=$NEWCOMPUTERNAME/g" /root/Documents/centrify-suite2.cfg
}

#########################################
# Function - networkConfig
#########################################
function networkConfig {

hwAddress=`cat /sys/class/net/ens32/address`
nicProperties=/etc/sysconfig/network-scripts/ifcfg-ens32

sed --in-place '/HWADDR/d' $nicProperties
sed --in-place '/ONBOOT/d' $nicProperties
echo -e "HWADDR=\"$hwAddress\"" >> $nicProperties
echo -e "ONBOOT=\"yes\"" >> $nicProperties

if [ "$NEWDOMAINNAME" = 'ext.local' ]; then
  read -e -p "Enter new ip address: " IPADDRESS
  read -e -p "Enter new subnet mask: " SUBNETMASK
  read -e -p "Enter new gateway: " GATEWAY
  read -e -p "IP: $IPADDRESS, SNM: $SUBNETMASK, GW: $GATEWAY, correct? [y] [n]: " ANSWER2

  while [[ $ANSWER2 != [Yy] ]]
  do
    read -e -p "Enter new ip address: " IPADDRESS
    read -e -p "Enter new subnet mask: " SUBNETMASK
    read -e -p "Enter new gateway: " GATEWAY
    read -e -p "IP: $IPADDRESS, SNM: $SUBNETMASK, GW: $GATEWAY, correct? [y] [n]: " ANSWER2
  done

  echo "Configuring network..."
  sed --in-place '/BOOTPROTO/d' $nicProperties
  sed --in-place '/DHCP_HOSTNAME/d' $nicProperties
  echo -e "NM_CONTROLLED=\"no\"" >> $nicProperties
  echo -e "BOOTPROTO=\"static\"" >> $nicProperties
  echo -e "IPADDR=\"$IPADDRESS\"" >> $nicProperties
  echo -e "NETMASK=\"$SUBNETMASK\"" >> $nicProperties
  echo -e "GATEWAY=\"$GATEWAY\"" >> $nicProperties

  # Build /etc/resolv.conf
  resolv=/etc/resolv.conf
  mv $resolv $resolv.BAK
  echo domain ext.local >> $resolv
  echo search ext.local >> $resolv
  echo nameserver 10.1.10.14 >> $resolv

  echo "Restarting network..."
  systemctl restart network
else
  systemctl restart network
fi

}

#########################################
# Function - configureSalt
#########################################
function configureSalt {

# grains=/etc/salt/grains
# PS3='Select the office in which this server belongs: '
# options=("Draper" "Ireland" "Australia" "Exit")
# select opt in "${options[@]}"
# do
#   case $opt in
#     "Draper")
#       echo "You chose Draper.  If this is correct, select exit."
#       location=Draper
#       ;;
#     "Ireland")
#       echo "you chose Ireland.  If this is correct, select exit."
#       location=Ireland
#       ;;
#     "Australia")
#       echo "you chose Australia.  If this is correct, select exit."
#       location=Australia
#       ;;
#     "Exit")
#       break
#       ;;
#     *) echo Invalid option! Select from the above list!;;
#   esac
# done

# echo roles: > $grains


# echo office: $location >> $grains

systemctl enable salt-minion
#minion will start after reboot (which is required when joining domain).

}

#########################################
# Function - joinAD
#########################################
function joinAD {

echo "Joining AD..."
if [ "$NEWDOMAINNAME" = 'stc.local' ]; then
  ADconfig=centrify-suite.cfg
elif [ "$NEWDOMAINNAME" = 'ext.local' ]; then
  ADconfig=centrify-suite2.cfg
else
  echo "ERROR!"
fi

/root/Documents/install-express.sh --express --suite-config /root/Documents/$ADconfig

sed -i 's/^PASSWD.*/PASSWD=password/' /root/Documents/centrify-suite.cfg
sed -i 's/^PASSWD.*/PASSWD=password/' /root/Documents/centrify-suite2.cfg

}

#########################################
# Function - secureRoot
#########################################
function secureRoot {

passwd root

}

#****************************************
# End of Funtions
#****************************************

main
