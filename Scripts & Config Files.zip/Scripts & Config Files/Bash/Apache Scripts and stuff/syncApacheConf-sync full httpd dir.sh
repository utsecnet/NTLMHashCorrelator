#!/bin/bash
# Checks to see if the apache directory (/etc/httpd) is in sync on STC-RProxy1.
# If not, it will sync and remotely restart the httpd service on RProxy1.
# Created by Rich Johnson for Storagecraft, May 3, 2012

# VARIABLES
remoteIP=10.1.3.10
localDir=/mnt/apache
apacheDir=/etc/httpd
remoteDir=$remoteIP:/$apacheDir
sync=off

# Log date
date

# Mount the remote apache directory
if mount $remoteDir $localDir; then
        echo "     Successfully mounted $localDir."
else
        echo "     There was an error. Exiting..."
        exit
fi

# Determine if files need to be syncd
if [ "diff -r --brief $apacheDir $localDir"  ]; then
        echo "     Contents of dir are newer, will need to sync."
        sync=on
else
        echo "     Contents of dir are the same.  Will not sync"
fi

# Sync if conf files are newer on local
if [ $sync = on ]; then
        echo "     OK, syncing..."

        # Sync changes from the local apache conf files to STC-RProxy1
        # Will only sync files in the /usr/local/bin/files text file
        /usr/bin/rsync -av $apacheDir/ $localDir/

        # Removing copied pid file
        if ssh $remoteIP rm /etc/httpd/run/httpd.pid; then
                echo "     Successfully removed pid file."
        else
                echo "     Failed removing pid file."
        fi

        # Running fuser to start apache w/o errors
        if ssh $remoteIP fuser -k -n tcp 80; then
                echo "     Successfully kill tcp pids."
        else
                echo "     Failed killing tcp pids."
        fi

        # Restart httpd on remote server (gracefully to not kill sessions!!!)
        if ssh $remoteIP /etc/init.d/httpd graceful; then
                echo "     Successfully restarted apache."
        else
                echo "     Failed restarting apache."
        fi
else
        echo "     No backups today..."
fi

#Unmount the remote apache directory and exit
if umount -l $localDir; then
        echo "     Successfully umounted $localDir."
else
        echo "     There was an error unmounting. Exiting..."
fi

exit
