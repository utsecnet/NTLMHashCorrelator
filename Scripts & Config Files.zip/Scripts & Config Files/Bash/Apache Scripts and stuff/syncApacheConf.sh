#!/bin/bash
# Checks to see if the apache directory (/etc/httpd) is in sync on STC-RProxy1.
# If not, it will sync and remotely restart the httpd service on RProxy1.
# Created by Rich Johnson for Storagecraft, May 3, 2012

# VARIABLES
remoteIP=ipaddress
localDir=/mnt/apache
apacheDir=/etc/httpd
remoteDir=$remoteIP:/$apacheDir
sync=off

# Log date
date

# Mount the remote apache directory
if mount $remoteDir $localDir; then
	echo "     Successfully mounted $localDir."
else
	echo "     There was an error. Exiting..."
	exit
fi

# Determine if files need to be syncd
if [ $apacheDir/conf/httpd.conf -nt $localDir/conf/httpd.conf ]; then
	echo "     httpd.conf is newer, will need to sync."	
	sync=on
else
	echo "     httpd.conf is the same.  Will not sync"
fi

if [ $apacheDir/conf.d/ssl.conf -nt $localDir/conf.d/ssl.conf ]; then
	echo "     ssl.conf is newer, will need to sync."	
	sync=on
else
	echo "     ssl.conf is the same.  Will not sync"
fi

# Sync if conf files are newer on local
if [ $sync = on ]; then
	echo "     OK, syncing..."
	
	# Sync changes from the local apache conf files to STC-RProxy1
	# Will only sync files in the /usr/local/bin/files text file
	/usr/bin/rsync -av --files-from=/usr/local/bin/files $apacheDir $localDir
	
	# Restart httpd on remote server (gracefully to not kill sessions!!!)
	if ssh $remoteIP /etc/init.d/httpd graceful; then
		echo "     Successfully restarted apache."
	else
		echo "     Failed restarting apache."
	fi
else
	echo "     No backups today..."
fi

#Unmount the remote apache directory and exit
if umount -l $localDir; then
	echo "     Successfully umounted $localDir."
else
	echo "     There was an error unmounting. Exiting..."
fi

exit
