#!/bin/sh

#datestamp=$(date +%Y-%m-%d)
datestamp=$(date)

if yum update -y; then
  echo "$datestamp:success" >> /var/log/update.log
else
  echo"$datestamp:fail" >> /var/log/update.log
fi