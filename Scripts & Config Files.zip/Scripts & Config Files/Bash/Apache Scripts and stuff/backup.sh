#!/bin/bash

# Variables
un=username
pw=password
datestamp=$(date +%Y-%m-%d)
localDir=/etc/httpd
localMount=/mnt/BackupServer
remoteDir=//ipaddress/STC-RProxy2
sync=off

# Do not edit
fullDestination=$localMount/config_files/$datestamp

# attempt to mount Windows shared drive to mount point
echo "Mounting remote file system."
if mount -t cifs $remoteDir -o username=$un,password=$pw $localMount; then
    echo "	Remote file system successfully mounted."
else
    echo "	There was an error mounting remote file system.  Exiting..."
    exit
fi

# Determine if files need to be syncd
if [ $localDir/conf/httpd.conf -nt $localMount/conf/httpd.conf ]; then
        echo "     httpd.conf is newer, will need to sync."
        sync=on
else
        echo "     httpd.conf is the same.  Will not sync"
fi

if [ $localDir/conf.d/ssl.conf -nt $localMount/conf.d/ssl.conf ]; then
        echo "     ssl.conf is newer, will need to sync."
        sync=on
else
        echo "     ssl.conf is the same.  Will not sync"
fi

# Sync conf files
if [ $sync = on ]; then
    echo "	OK, syncing..."
    /usr/bin/rsync -av --files-from=/usr/local/bin/files $localDir $localMount
    mkdir -p $fullDestination
    /usr/bin/rsync -av --files-from=/usr/local/bin/files $localDir $fullDestination
else
    echo "	Sync failed. Exiting..."
fi

#move rotated log files
mkdir -p $localMount/logs
mv $localDir/logs/*2012* $localMount/logs

#unmount mount point and remove the /bak dir from system
echo "	Network drive will now be unmounted."
umount $localMount
exit
