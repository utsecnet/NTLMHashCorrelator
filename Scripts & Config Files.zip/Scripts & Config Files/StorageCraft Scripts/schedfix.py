# -*- coding: utf-8 -*-
# Copyright (C) 2015 StorageCraft Technology Corporation. All rights reserved.
# This source code (including its associated software) is owned by
# StorageCraft Technology Corporation and is protected by United States and
# international intellectual property law, including copyright laws, patent
# laws, and treaty provisions.
"""Fix the schedule for STC backup jobs.

We lose the randomization by having split the schedule into two rules, so this
fixes that by returning to a single rule.

Run like:

%ProgramFiles%/StorageCraft/spx/python schedfix.py <username> <password>

Errors result in a stack trace.
"""
from getpass import getpass
import json
import random
import requests
import sys

BASE_URL = 'https://localhost:13581/spx/'


s = requests.Session()
s.verify = False


def url(relative_path):
    return BASE_URL + relative_path


def get_credentials():
    if len(sys.argv) < 3:
        username = raw_input('Username: ')
        password = getpass('Password: ')
        return username, password
    return sys.argv[1], sys.argv[2]


def login(username, password):
    payload = {'username': username, 'password': password}
    headers = {'content-type': 'application/json'}
    r = s.post(url('auth/login'), data=json.dumps(payload), headers=headers)
    if r.status_code != requests.codes.ok:
        raise Exception('Login failed: {}'.format(r.status_code))
    return r.json()['token']


def get_jobs(token):
    headers = {'Authorization': 'Token ' + token}
    r = s.get(url('v1/backup'), headers=headers)
    if r.status_code != requests.codes.ok:
        raise Exception('Getting jobs failed: {}'.format(r.status_code))
    return r.json()


def find_job_to_fix(jobs):
    for job in jobs:
        if job['name'].startswith('STC '):
            return job
    raise Exception('Job not found')


def fix_job_schedule(job, token):
    minutes = random.choice(range(60))
    rule = job['schedule']['rules'][0]
    rule['start'] = 'T00:{:02}:00'.format(minutes)
    rule['end'] = 'T23:59:00'
    job['schedule']['rules'] = [rule]
    payload = job
    headers = {
        'content-type': 'application/json',
        'Authorization': 'Token ' + token
    }

    r = s.put(url('v1/backup/' + job['uuid']), data=json.dumps(payload), headers=headers)
    if r.status_code != requests.codes.ok:
        raise Exception('Job update failed: {}'.format(r.status_code))


def main():
    print 'StorageCraft SPX Schedule Updater'
    print 'Please enter your domain credentials'
    print 'Contact StorageCraft IT if you have concerns about this.'
    authenticated = False
    while not authenticated:
        username, password = get_credentials()
        try:
            token = login(username, password)
            authenticated = True
        except Exception as e:
            print e

    jobs = get_jobs(token)
    job = find_job_to_fix(jobs)
    fix_job_schedule(job, token)


if __name__ == '__main__':
    main()
