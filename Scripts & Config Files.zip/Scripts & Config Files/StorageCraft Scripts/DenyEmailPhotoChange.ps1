﻿<#
Script for disabling user's access to change profile photos in OWA
Written by Tyler T. and Brady Y. For StorageCraft
http://www.msexchange.org/kbase/ExchangeServerTips/ExchangeServer2013/OutlookOWA/prevent-users-changing-photo-owa.html
Last modify date: 8/23/2016
#>

#Import AD module into the current powershell session if it not currently imported.
If (!(Get-module ActiveDirectory )) 
{
    Import-Module ActiveDirectory
}

#$users = get-aduser -filter {enabled -eq $true} –SearchBase 

#Disables the ability for users to change their picture by clicking on their name in top right corner -> change (underneath their current picture.)
#This setting is disabled for the entire server not user by user.
Get-OwaVirtualDirectory -Server "STC-IE-Exchange" | Set-OwaVirtualDirectory -SetPhotoEnabled $False

#Disables each users ability to change their picture by going to Options -> Edit Information -> Photo -> Change. (Removes the change button)
#This setting is set to the OWA Mailbox Policy on the server, then the policy has to be applied to each mailbox individually.
Get-OWAMailboxPolicy | Set-OWAMailboxPolicy -SetPhotoEnabled $False 

$mailboxes = Get-CASMailbox
foreach ($mailbox in $mailboxes)
{
    Set-CASMailbox $mailbox.Name -OWAMailboxPolicy Default
}


