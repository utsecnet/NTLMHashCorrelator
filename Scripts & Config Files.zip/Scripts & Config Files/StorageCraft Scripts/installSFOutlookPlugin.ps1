﻿<#
.SYNOPSIS
    This script manages all aspects of  from installation, to Job creation, and ensures the job stays in compliance.  Much of this scripts funtionality can be passed to ShadowControl. 
    However, there are several key features ShadowControl is missing.
        - Random passwords for endpoints
        - Round-Robin backup destinations
        - Multiple backup stores
        - Manage endpoints at different locations that may not have access to a SC Appliance
    This script is called via a scheduled task or an immediate task (via GPO) with the following details:
        General Tab
            - runas: SYSTEM (does not require 'run as highest privileges'
        Actions Tab
            - Program/script: powershell.exe
            - Arguments: -executionpolicy bypass -command \\server\share\installspx.ps1 <location> <platform>


.DESCRIPTION 
    - Creates a backup destination on the backup server if not already created.  Uses round-robin logic to disperse backup destinations to a multitude of backup servers and volumes
    - Checks the locally installed version of SPX, against the msi installer located on a file share.  
        - If the hosted file is a higher version it upgrades.
        - If the hosted file is <= installed vresion it contnues
    - Checks the spxservice.  If it's stopped, it attempts to start it.
    - Checks if SPX is activated, if not, it attempts to activate.
    - Checks to ensure the SPX job is the IT managed job name. If not, it deletes all jobs and creates a job in accordance iwth compliance policies

.PARAMETER location
    Summary: Declairs at what office the endpoint is located.  This will be used to logically define where the endpoints backup destination will be stored
    Required: Yes 
    Example: Draper

.PARAMETER platform
    Summary: Declairs the endpoint platform (workstation or server).  The platform will determine what key will be used when activating SPX.
    Required: Yes
    Example: Server

.Example
    >.\installSPX Draper WKS
    This will configure a backup job for a workstation located in Draper.

    >.installSPX Ireland Server
    This will configure a backup job for a server located in Ireland.

.NOTES
    NAME: installSPX.ps1
    AUTHOR: Rich Johnson
    EMAIL: rich.johnson@storagecraft.com
    REQUIREMENTS: coming soon...
    Change Log:
        2016-05-09 - Cleanup and comments added
        2016-05-08 - Creates Job
                   - Activation settings added
        2016-05-05 - Initial creation
#>

# Location where this script will log to
# This is different than the msiexec installation log file, which you specify in the install command
$logLocation = "\\stc-file\stc\it\salesforce\endpoint logs\$env:username.txt"

# Turn this to on if you want additional debug logging.  Off will overwrite On if you uncomment the <debug = "off"> line.
# Debug logging will show you the value of all variables so you can see if varable logic problems exist
$debug = "on"
#$debug = "off"

$blurb = "no"

# All actions are logged by calling this function
function logging ($level, $text) {
    if ($debug -ne "on" -and $level -eq "D") {
        return
    }
    $timeStamp = get-date -Format "yyyy-MM-dd HH:mm:ss.fff"

    if ($blurb -ne "yes") {
        # Override the existing log file so it does not grow out of control
        Write-Output "$timeStamp I New log created" > $logLocation
        $script:blurb = "yes"
    }

    Write-Output "$timeStamp $level $text" >> $logLocation
}

# Name of the file server that holds the installer
$fileServer = "stc-file"
logging "D" "fileServer: $fileServer"

# Name of the file share that holds the installer
$share = "stc\it\salesforce\salesforceforoutlook"
logging "D" "share: $share"

# Determine if the computer is 32bit or 64bit
if ($env:PROCESSOR_ARCHITECTURE -eq "AMD64") {
    # For x86_64
    $installFile = "SalesforceForOutlook_x64.msi"
}
else {
    # For x86
    $installFile = "SalesforceForOutlook.msi"
}
logging "D" "installFile: $installFile"

# Full path to the installer
$installFilePath = "\\$fileServer\$share\$installFile"
logging "D" "installFilePath: $installFilePath"

# Path to the msi install logs
$installLog = "$env:programdata\installSFOutlookPlugin.txt"
logging "D" "installLog: $installLog"

#########
# Install
#########

# Install

if (Test-Path $installFilePath) {
    logging "D" "install command: msiexec /qn /lvoicewarmupx $installLog /package $installFilePath REBOOT=ReallySuppress"
    #Start-Process -FilePath msiexec -ArgumentList /qn, /lvoicewarmupx, $installLog, /package, $installFilePath, REBOOT=ReallySuppress -Wait

    # Check if installed correctly
    try {
        if (get-process sfdcmsol -EA SilentlyContinue) {
            logging "I" "Process is running."
        }
        else {
            logging "E" "Process is not running.  Check the install log located at $installLog."
        }
    }
    catch {
        logging "E" $Error[0]
    }
}
else {
    logging "E" "$installFilePath does not exist"
}


# Exit
logging "I" "Exiting Script"