﻿<#
.SYNOPSIS
    This script manages all aspects of SPX from installation, to Job creation, and ensures the job stays in compliance.  Much of this scripts funtionality can be passed to ShadowControl. 
    However, there are several key features ShadowControl is missing.
        - Random passwords for endpoints
        - Round-Robin backup destinations
        - Multiple backup stores
        - Manage endpoints at different locations that may not have access to a SC Appliance
    This script is called via a scheduled task or an immediate task (via GPO) with the following details:
        General Tab
            - runas: SYSTEM (does not require 'run as highest privileges'
        Actions Tab
            - Program/script: powershell.exe
            - Arguments: -executionpolicy bypass -command \\server\share\installspx.ps1 <location> <platform>


.DESCRIPTION 
    - Creates a backup destination on the backup server if not already created.  Uses round-robin logic to disperse backup destinations to a multitude of backup servers and volumes
    - Checks the locally installed version of SPX, against the msi installer located on a file share.  
        - If the hosted file is a higher version it upgrades.
        - If the hosted file is <= installed vresion it contnues
    - Checks the spxservice.  If it's stopped, it attempts to start it.
    - Checks if SPX is activated, if not, it attempts to activate.
    - Checks to ensure the SPX job is the IT managed job name. If not, it deletes all jobs and creates a job in accordance iwth compliance policies

.PARAMETER location
    Summary: Declairs at what office the endpoint is located.  This will be used to logically define where the endpoints backup destination will be stored
    Required: Yes 
    Example: Draper

.PARAMETER platform
    Summary: Declairs the endpoint platform (workstation or server).  The platform will determine what key will be used when activating SPX.
    Required: Yes
    Example: Server

.Example
    >.\installSPX Draper WKS
    This will configure a backup job for a workstation located in Draper.

    >.installSPX Ireland Server
    This will configure a backup job for a server located in Ireland.

.NOTES
    NAME: installSPX.ps1
    AUTHOR: Rich Johnson
    EMAIL: rich.johnson@storagecraft.com
    REQUIREMENTS: coming soon...
    Change Log:
        2017-05-09 - Cleanup and comments added
        2017-05-08 - Creates Job
                   - Activation settings added
        2017-05-05 - Initial creation
#>

# Receive parameters
# This script is shared throughout the organization by server and workstations located throughout the world.  
# These parameters indicate if the device is a Server or Workstation (they get different keys) and at which office it is located (different backup servers).
param([string]$location, [ValidateSet("WKS","Server")][string]$platform)

# Location where this script will log to
# This is different than the msiexec installation log file, which you specify in the install command
$logLocation = "\\stc-file\stc\it\spx\endpoint logs\$env:computername.txt"

# Turn this to on if you want additional debug logging.  Off will overwrite On if you uncomment the <debug = "off"> line.
# Debug logging will show you the value of all variables so you can see if varable logic problems exist
$debug = "on"
#$debug = "off"

# All actions are logged by calling this function
function logging ($level, $text) {
    if ($debug -ne "on" -and $level -eq "D") {
        return
    }
    $timeStamp = get-date -Format "yyyy-MM-dd HH:mm:ss.fff"

    if ($blurb -ne "yes") {
        # Override the existing log file so it does not grow out of control
        Write-Output "$timeStamp I New log created" > $logLocation
        $script:blurb = "yes"
    }

    Write-Output "$timeStamp $level $text" >> $logLocation
}

# Verify we have received two parameters from the schedueld task that calls this script
if (!$location) { 
    logging "E" "Argument 1 (location) does not exist!"
    exit
}
if (!$platform) { 
    logging "E" "Argument 2 (platform) does not exist!"
    exit
}

# Set variables for Draper Office
if ($location -eq "Draper") {
    $fileServer = "stc-file"
    if ($platform -eq "Server") {
        $backupServer = "stc-backup"
    }
    if ($platform -eq "WKS") {
        $backupServer = "stc-backup-wks"
    }
}

# Set variables for Australia Office
if ($location -eq "Australia") {
    $fileServer = "s-au-file"
    $backupServer = "s-au-backup"}

# Set variables for Ireland Office
if ($location -eq "Ireland") {
    $fileServer="stc-ie-file"
    if ($platform -eq "Server") {
        $backupServer = "s-ie-backup"
    }
    if ($platform -eq "WKS") {
        $backupServer = "s-ie-backup-wks"
    }
    # Ireland does not have a small or large share.  They only have the front plane of disks in use.
    $backupPath="\\$backupServer\backups\$($env:computername)"
}

# Where in the registry does SPX have product version information that we can see what version is currently installed?
$regLocation = "HKLM:\SOFTWARE\StorageCraft Technology Corporation\spx"

# What is the name of the property that holds the version information?
$regProperty = "InstalledVersion"

# What is the name of the installer?
# When you download SPX, you must rename it to this name for it to work.
$installer = "spx.msi"

# Where is the SPX install directory
$installerPath = "\\$fileServer\STC\IT\SPX\$installer"

# What is the name of the SPX service?
$serviceName = "spxservice"

# SPX installed on a server requires a server key.
# The platform is passed in as a paramater from the scheduled task
if ($platform -eq "Server") {
    $key = "f556-b208-260c-b3e3"
}
if ($platform -eq "WKS") {
    $key = "4abf-7a6c-15d8-0641"
}

#############################
# Functions - Pre install SPX
#############################

# Create backup destination on correct server for new deployment of SPX
function createBackupDirectory ($share, $number) {
    $script:destination = "\\$backupServer\$share\$env:computername"
    logging "I" "Will create destination at $destination"
    [void] (New-Item -path $destination -ItemType directory -Force)
    if (Test-Path $destination) {
        logging "I" "Destination: $destination created successfully."
        if ($location -eq "Ireland") {
            return
        }
    }
    else {
        logging "E" "Failed to create destination: $destination.  Check permissions and path name."
        exit
    }
    [void] (icacls $destination /grant:r "stc\$env:computername`$:(OI)(CI)(RX,W)" /T)
    if ($number -eq "1") {2 > $numberFile}
    if ($number -eq "2") {3 > $numberFile}
    if ($number -eq "3") {1 > $numberFile}
}

# Check installed SPX version
function checkInstalledVersion {
    if (Test-Path $regLocation) {
        $script:installedVersion = Get-ItemProperty -Path $regLocation | Select-Object -ExpandProperty $regProperty
        logging "I" "Registry shows SPX $installedVersion currently installed."
    }
    else {
        logging "I" "$reglocation does not exist."
    }
}

# Check hosted SPX version
function checkHostedVersion {
    $comObjWI = New-Object -ComObject WindowsInstaller.Installer
    $msiDatabase = $comObjWI.GetType().InvokeMember("OpenDatabase","InvokeMethod",$Null,$comObjWI,@($installerPath,0))
    $query = "SELECT Value FROM Property WHERE Property = 'ProductVersion'"
    $view = $MSIDatabase.GetType().InvokeMember("OpenView","InvokeMethod",$null,$msiDatabase,($query))
    $view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)
    $record = $View.GetType().InvokeMember("Fetch","InvokeMethod",$null,$view,$null)
    $script:hostedVersion = $Record.GetType().InvokeMember("StringData","GetProperty",$null,$record,1)
    logging "I" "Version hosted on file server: SPX $hostedVersion."
}

##############################
# Functions - Post install SPX
##############################

# Reads admin token from $configFile
function authenticate () {
    $config = Get-Content $configFile | ConvertFrom-Json | Select-Object admin_token
    $token = $config.psobject.properties.value
    return @{"Authorization" = "Token $token"}
}

function url ($relativePath) {
    return $baseUrl + $relativePath
}

function rget ($url) {
    $header = authenticate
    return Invoke-RestMethod -Uri $url -Headers $header -Method Get
}

function rdel ($url) {
    $header = authenticate
    return Invoke-RestMethod -Uri $url -Headers $header -Method Delete
}

# Checks the activation status for SPX
# Example of what this function returns:
# @{status=3; features=; days_left=0; phone=; company=Company; call_home=0; product_key=1111-1111-1111-1111; email=; trial=False; host=; user=Bob Hope; type=default; port=443; types=System.Object[]}
# status=0: activated
# status=3: no activated
function checkActivationStatus () {
    $script:license = Invoke-RestMethod -Uri $activateUrl -Headers $header -Method Get 
}

# Gets existing jobs
function getJobs () {
    $url = url "v1/backup"
    try {
        $job = rget($url)
    }
    catch {
        logging "E" "Getting jobs failed: $($Error[0])"
        logging "I" "If SPX was just installed, a reboot is required. Otherwise, check that the service is running."
        exit
    }
    return $job
}

# Delete all jobs because managed job does not exist
function deleteJobs ($jobs) {
    foreach ($job in $jobs) {
        try {
            logging "I" "Deleting job: $($job.name)"
            $url = url "v1/backup/$($job.uuid)"
            rdel $url
        }
        catch {
            logging "E" "Deleting job $($job.name) failed: $($Error[0])"
            exit
        }
    }
}

# Get existing destinations
function getDestinations () {
    $url = url "v1/destination"
    try {
        $r = rget $url
    }
    catch {
        logging "E" "Getting destinations failed: $($Error[0])"
    }
    return $r
}

# Delete destinations
function deleteDestinations ($dests) {
    foreach ($dest in $dests) {
        $url = url "v1/destination/$($dest.uuid)"
        try {
            logging "I" "Deleting destination: $($dest.name)"
            $r = rdel $url
        }
        catch {
            logging "E" "Deleting destination failed: $($Error[0])"
        }
    }
}

logging "D" "location: $location"
logging "D" "platform: $platform"
logging "D" "fileServer: $fileServer"
logging "D" "backupServer: $backupServer"
logging "D" "backupPath: $backupPath"
logging "D" "regLocation: $regLocation"
logging "D" "regProperty: $regProperty"
logging "D" "installer: $installer"

###################################################
# Check if Backup Destination exists, Create if not
###################################################

# Confirm backup server is online.  If it is, check for existing destination.  If not, exit.
if (Test-Connection -ComputerName $backupServer -Count 1 -ErrorAction SilentlyContinue) {
    logging "I" "Backup server $backupServer is online."

    # Check if a backup destination already exists.  The Ireland office's backup server is different than all other offices in that it does not have multiple volumes to hold backups.  It has a single volume, labled "backups".
    if ($location -eq "Ireland") {
        if (Test-Path \\$backupServer\backups\$env:computername) {
            $destination = "\\$backupServer\backups\$($env:computername)"
        }
    }
    else {
        if (Test-Path \\$backupServer\small\$env:computername) {
            $destination = "\\$backupServer\small\$($env:computername)"
        }
        if (Test-Path \\$backupServer\large\$env:computername) {
            $destination = "\\$backupServer\large\$($env:computername)"
        }
    }
}
else {
    logging "E" "$backupServer is offline."
    exit
}

if ($destination) {
    logging "I" "Destination found: $destination"
}
elseif ($location -eq "Ireland") {
    createDestination "backups" "1"
}
else {
    logging "I" "Destination not found."
    $numberFile = "\\$backupServer\small\number.txt"
    if (Test-Path $numberFile) {
        logging "D" "NumberFile exists."
        $numberFileContents = Get-Content $numberFile | Out-String
        logging "D" "NumberFile contains a $numberFileContents"
        if ($numberFileContents -like "1*") {
            createBackupDirectory "small" "1"
        }
        elseif ($numberFileContents -like "2*") {
            createBackupDirectory "large" "2"
        }
        elseif ($numberFileContents -like "3*") {
            createBackupDirectory "large" "3"
        }
        else {
            logging "E" "Something went wrong."
            exit
        }
    }
    else {
        logging "E" "Number file not found or permissions are incorrect."
        exit
    }
}

##########################################################################
# Check if SPX is installed and upto date.  If not, install latest version
##########################################################################
checkInstalledVersion
if (get-variable installedVersion -ErrorAction SilentlyContinue) { 
    checkHostedVersion
    # Installed but needs an upgrade
    if ($installedVersion -lt $hostedVersion) {
        $preUpgradeVersion = $installedVersion
        logging "D" "preUpgradeVersion: $preUpgradeVersion"
        logging "I" "SPX $installedVersion is installed, but SPX $hostedVersion is available.  Will upgrade."

        # if its an upgrade, install command should not have a key or it may cause SPX to reactivate.  Business Systems can detect reactivations.
        logging "I" "install command: msiexec /qn /lvoicewarmupx C:\programdata\installSPX2.txt /package \\stc-file\stc\it\spx\spx.msi IACCEPT=STORAGECRAFT.EULA REBOOT=ReallySuppress"
        Start-Process -FilePath msiexec -ArgumentList /qn, /lvoicewarmupx, C:\programdata\installSPX2.txt, /package, \\stc-file\stc\it\spx\spx.msi, IACCEPT=STORAGECRAFT.EULA, REBOOT=ReallySuppress -wait

        checkInstalledVersion
        $postUpgradedVersion = $installedVersion
        logging "D" "postUpgradedVersion: $postUpgradedVersion"
        if ($postUpgradedVersion -eq $hostedVersion) { 
            logging "I" "Successfully upgraded from SPX $preUpgradeVersion to SPX $postUpgradedVersion"
            logging "I" "Cannot activate or create job until a reboot, so we must exit"
            exit
        }
        if ($postUpgradedVersion -lt $hostedVersion) { 
            logging "E" "Failed upgrading SPX $preUpgradeVersion to SPX $hostedVersion."
            exit
        }
    }
    # Installed and current
    elseif ($installedVersion -eq $hostedVersion) {
        logging "I" "SPX $installedVersion is current.  No need to upgrade."
    }
    # Installed at a later version than what we provide
    else {
        logging "I" "SPX $installedVersion is installed, which is greater than version $hostedVersion on the file server.  Maybe the user manually upgraded?"
    }
}
# Not installed, so we will install
else {
    logging "I" "SPX is not currently installed."
    logging "I" "install command: msiexec /qn /lvoicewarmupx C:\programdata\installSPX2.txt /package \\stc-file\stc\it\spx\spx.msi IACCEPT=STORAGECRAFT.EULA KEY=$key NAME=$env:computername ORG=STC REBOOT=ReallySuppress"
    Start-Process -FilePath msiexec -ArgumentList /qn, /lvoicewarmupx, C:\programdata\installSPX2.txt, /package, \\stc-file\stc\it\spx\spx.msi, IACCEPT=STORAGECRAFT.EULA, KEY=$key, NAME=$env:computername, ORG=STC, REBOOT=ReallySuppress -Wait
    checkInstalledVersion

    # Verify SPX installed correctly
    if (get-variable installedVersion -ErrorAction SilentlyContinue) { 
        # installed successfully
        logging "I" "Successfully installed SPX $installedVersion"
        logging "I" "Cannot activate or create job until a reboot, so we must exit"
        exit
    }
    else {
        # installation failed
        logging "E" "Failed to install SPX."
        exit
    }
}

# Check if SPX service is running. Attempt to start if not
$serviceStatus = $(get-service $serviceName).Status
logging "I" "$serviceName status: $serviceStatus"
if ($serviceStatus -ne "Running") {
    # Attempt to start the service
    logging "I" "Attempting to start service."
    Start-Service $serviceName
    $serviceStatus = $(get-service $serviceName).Status
    if ($serviceStatus -ne "Running") {
        logging "E" "Failed to start service."
        exit
    }
    else {
        logging "I" "Successfully restarted service."
        # If we dont sleep for a few seconds, we won't be able to access the REST API in the next several steps
        Start-Sleep -s 3
    }
}

##############################
# Configure SPX and create job
##############################

# Must esatablish a trust relationship for the SSL/TLS secure channel. This is used when accessing the SPX API.
add-type @"
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
"@
[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy

try {
    # Set the payload for creating the destination
    $destinationPayload = @{
        "name" = "$backupServer";
        "path" = $destination;
        "store_type" = 1
    }

    # Convert the payload to JSON
    $destinationJson = $destinationPayload | ConvertTo-Json

    # Format the name of the IT managed backup job
    $jobName = "STC $platform - $env:computername"

    # When we finish creating the job, we email the IT department the backup job password
    $smtpFrom = "$backupServer@storagecraft.com"
    $serverEncryptionPassword = "50l1d50urc35af3"
    $smtpHost = "mail.storagecraft.com"
    $smtpTo = "helpdesk@storagecraft.com"

    # Location of the spx_config.json file, used to create the job via the SPX API
    $configFile = "$env:ProgramData\StorageCraft\spx\spx_config.json"

    # base URL of the SPX API
    $baseUrl = "https://localhost:13581/spx/"

    # Generate authentication tockens
    $header = authenticate

    # Object list of all jobs currently in SPX
    $jobs = getJobs

    # The following variables determine the start/stop time of the backup job.  You want to stagger your backups so as to not flod your network
    # Randomizing the start time will help with this.
    $minutes = (Get-Random -maximum 59).ToString("00")
    $start = "T00:{0}:00" -f $minutes
    $end = "T23:59:00"

    # Define the backup schedule according to your complaince requirements
    if ($platform -eq "Server") {
        $days = @(0, 1, 2, 3, 4, 5, 6)
        $sched = "All days of the week"
        $repeats = "60"
        $password = $serverEncryptionPassword
        $body = "Please set up replication in ImageManager."
    }
    if ($platform -eq "WKS") {
        $days = @(1, 2, 3, 4, 5)
        $sched = "Weekdays"
        $repeats = "90"
        $password = ([char[]]([char]'a'..[char]'z') + 0..9 + [char[]]([char]'A'..[char]'Z') | sort {get-random})[0..7] -join ''
        $body = $password
    }

    # URI after the base URL
    $activateUrl = url "v1/license"

    # Activation configuration
    $activateConfig = @{
            "company" = "STC";
            "user" = "$env:computername";
            "product_key" = $key;
        }

    # Convert activation configuration to JSON
	$activateJson = $activateConfig | ConvertTo-Json

    logging "D" "activateUrl: $activateUrl"
    logging "D" "activateConfig company: $($activateConfig.company)"
    logging "D" "activateConfig user: $($activateConfig.user)"
    logging "D" "activateConfig product_key: $($activateConfig.product_key)"
    logging "D" "activateJson: $activateJson"

    # Check if activated.  If not, then activate
    checkActivationStatus
    logging "D" "license: $license"

    if ($license.status -eq 0) {
        logging "I" "SPX is activated."
    }
    else {
        logging "I" "SPX is not currently activated."
        try {
            [void] (Invoke-RestMethod -Uri $activateUrl -Headers $header -Body $activateJson -Method Put -ContentType 'application/json')
            checkActivationStatus
            if ($license.status -eq 0) {
                logging "I" "SPX was successfully activated."
            }
            else {
                logging "E" "SPX failed activation."
            }
        }
        catch {
            logging "E" "Could not activate. Error: $($Error[0])"
        }
    }
    
    # Look at endpoint's confgured jobs and destinations.  If the company managed job does not exist, delete all jobs and destinations, then create managed destination.
	foreach ($job in $jobs) {
		if ($job.name -eq $jobName) {
			logging "I" "Job already configured."
			exit   
		}	
	}

    logging "D" "Destination name: $($destinationPayload.name)"
    logging "D" "Destination path: $($destinationPayload.path)"
    logging "D" "Destination store_type: $($destinationPayload.store_type)"
    logging "D" "jobName: $jobName"
    logging "D" "smtpFrom: $smtpFrom"
    logging "D" "smtpHost: $smtpHost"
    logging "D" "smtpTo: $smtpTo"
    logging "D" "configFile: $configFile"
    logging "D" "baseUrl: $jobName"
    logging "D" "minutes: $minutes"
    logging "D" "start: $start"
    logging "D" "end: $end"
    logging "D" "days: $days"
    logging "D" "sched: $sched"
    logging "D" "repeats: $repeats"
    logging "I" "Managed job not found.  Will delete existing jobs and destinations."

    deleteJobs $jobs
    $destinations = getDestinations
    deleteDestinations $destinations
    
    # Create Destination
    try {
        $destinationUrl = url "v1/destination"
        $destId = Invoke-RestMethod -Uri $destinationUrl -Headers $header -Body $destinationJson -Method Post -ContentType 'application/json'
    }
    catch {
        logging "E" "Creating destination failed: $($Error[0])"
    }
    
    logging "I" "Creating SPX destination - name: $($destinationPayload.name), path: $($destinationPayload.path)"
    
    # Define additional compliance settings for job creation
    $settings= @{
        "comment" = "StorageCraft IT managed backup job";
        "compression" = 5;           # 0 = none, 5 = standard, 6 = best
        "encryption" = 4;            # 4 = aes 256
        "enc_password" = $password;
        "sch_type" = 4;              # 4 = continuous incremental
        "io_throttle" = 50;
        "gen_keyfile" = "True"
    };
    $offsets = @{
        "days"=$days
    }
    $rules = @{
        "start" = $start;
        "end" = $end;
        "frequency" = 0;             # 0 = weekly, 1 = monthly
        "repeats" = $repeats;
        "mode" = 1;                  # 0 = full, 1 = incremental
        "offsets" = $offsets
    }
    $schedule = @{
        "rules" = @($rules)
    }
    $jobConfig = @{
        "name" = $jobName;
        "destination" = $destId;
        "settings" = $settings;
        "schedule" = $schedule;
        "volume_scheme" = 1          # 0 = all, 1 = system only, 2 = data only
    } 

    logging "D" "settings comment: $($settings.comment)"
    logging "D" "settings compression: $($settings.compression)"
    logging "D" "settings encryption: $($settings.encryption)"
    logging "D" "settings sch_type: $($settings.sch_type)"
    logging "D" "settings io_throttle: $($settings.io_throttle)"
    logging "D" "settings gen_keyfile: $($settings.gen_keyfile)"
    logging "D" "offsets days: $($offsets.days)"
    logging "D" "rules start: $($rules.start)"
    logging "D" "rules end: $($rules.end)"
    logging "D" "rules start: $($rules.start)"
    logging "D" "rules frequency: $($rules.frequency)"
    logging "D" "rules repeats: $($rules.repeats)"
    logging "D" "rules mode: $($rules.mode)"
    logging "D" "jobConfig name: $($jobConfig.name)"
    logging "D" "jobConfig destination: $($jobConfig.destination)"
    logging "D" "jobConfig schedule: $($jobConfig.schedule)"
    logging "D" "jobConfig volume_scheme: $($jobConfig.volume_scheme)"
 
    # Create the job
    try {
        $jobUrl = url "v1/backup"
        logging "D" "jobUrl: $jobUrl"

		$jobJson = $jobConfig | ConvertTo-Json -Depth 5
        ####################################################################################
        #
        # WARNING - uncommneting this will result in the backup password being logged!!!!!!!
        #
        ####################################################################################
        #logging "D" "jobJson: $jobJson"

        [void] (Invoke-RestMethod -Uri $jobUrl -Headers $header -Body $jobJson -Method Post -ContentType 'application/json')
    }
    catch {
        logging "E" "Creating job failed: $($Error[0])"
    }

    # Verify job created
    $jobs = getJobs
    $jobs | ForEach-Object { 
        if ($_.name -eq $jobName) {
            logging "I" "Job created successfully."
        }
        else {
            logging "E" "Something went wrong."
        }
    }
    
    # Send an email with backup password for workstations to the IT team
    Send-MailMessage -To $smtpTo -From $smtpFrom -Subject ($env:COMPUTERNAME + ' Backup Job Created') -Body $body -SmtpServer $smtpHost
    if($?) {
        logging "I", "Email sent to $smtpTo"
    }
    else {
        logging "E" "Failed to send email."
    }
}
catch {
    # If something goes wrong, delete any jobs. Otherwise, we'll have a job for which we don't know the encryption key, and if we try to
    # run this script again, it'll exit because the job already exists.
    logging "E" "Error configuring SPX; rolling back any job creation. Error reported was: $($Error[0])"
    try {
        $jobs = getJobs
        delete_jobs($jobs)
    }
    catch {
        logging "E" "Failed to roll back job creation"
    }
}
finally {
    logging("I", "Exiting Script")
}