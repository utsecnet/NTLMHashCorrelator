﻿<#
.SYNOPSIS
    This script updates each user's information for email signatures and ensures that it is uniform across the company.
    ADuserInfo.ps1
    Author: Brady Young | StorageCraft Technology Corporation

.DESCRIPTION
    - Set each user's department information based on the OU the user object is located in.
    - Set each user's address, company name, and web site (home page) based on the Locale OU the object is located in. (i.e. Australia, Utah, Singapore, Ireland, Europe, etc...)
    - The user's home page is based upon their locale as well as if they are in Marketing or Sales (currently Marketing and Sales only in the Americas region get the URL for the Cloud2Cloud site.)
    - This information that is set is mainly used for email signatures.  We are currently using Exclaimer for Exchange. 

.NOTES
    NAME: ADuserInfo.ps1
    AUTHOR: Brady Young
    EMAIL: brady.young@storagecraft.com
    REQUIREMENTS:
    Change Log:
        2016-23-09 - Added Wisconsin users
        2016-28-11 - Added a section to change the home page for all Sales and Marketing users (based on the department property of their AD user object) to be http://goto.storagecraft.com/cloud-backup.html.
        2016-29-11 - Added the Department Function that sets each user's department
                   - Made the section that sets all the user info (i.e. address, home page, etc...) into it's own function, the UserInfo function. 
        2016-12-12 - Combined the two functions Department and UserInfo.
                   - Added new variables and decreased processing by only pulling the canonicalname,department,company,pobox,streetaddress,city,state,postalcode,homepage,office.  Instead of pulling all properties for each individual user.
                   - Added debugging and logging. 
        2017-22-02 - Added extensionAttribute1 because Exclaimer Cloud doesn't pull the HomePage AD Property like the on prem Exclaimer does. It does pull the extensionAttributes so we will use extensionAttribute1 to set the hyperlinks in the email signature.
        2017-06-04 - Modified Wisconsin address to their new building.
        2017-12-04 - Changed homepage attribute for sales and marketing (line 217)
        2017-14-04 - Heavily modified the script to help with processing time and ticks.
                   - Added a part where a speical home page is determined to only include sales and marking in Americas region (Line 239).
                   - Removed processing of extensionAttribue1 since we aren't using Exclaimer Cloud right now...

.TODO
#>


# Import AD module into the current powershell session if it not currently imported.
If (!(Get-module ActiveDirectory )) 
{
    Import-Module ActiveDirectory
}

# Uncomment the =1 to enable debugging.  Comment to Disable.
$debug = 0
$debug = 1

# Set the AD server
$server = "STC-UT-DC2"

# All user accounts from all local and remote offices
$Allusers = Get-ADUser -Server $server -SearchBase "OU=Employees,OU=Users,OU=StorageCraft,DC=stc,DC=local" -Filter '*' -Properties canonicalname,department,company,pobox,streetaddress,city,state,postalcode,homepage,office,extensionAttribute1

# Logging is tracked by the scheduled task, by using the argument: -executionpolicy bypass -command C:\users\admin\documents\ADuserInfo.ps1 2>&1 > C:\ProgramData\updateaduserinfo.txt
# Log results of actions
function logging($string) {
    $timestamp = get-date -Format "yyyy-MM-dd HH:mm:ss.fff"
    if ($debug -eq 1 ) {
        Write-Output "$timestamp - $string"
    }
}

# This function actually changes the User's information.  It grabs the variables described from the function "UserInfo" starting on line 223, where this (ChangeUserInfo) function is called.
Function ChangeUserInfo ($user, $userName, $Property, $value, $newValue) {
        
        $property_newValue = @{$Property=$newValue}

        if ( $value -ne $newValue ) {
        Set-ADUser $user @property_newValue
        # Log if anything was changed.
        if($?) {
            if ($debug -eq 1 ) {
                logging "Changed $userName's $Property from $value to $newValue"
            }
        }
    }
}

logging "Start Script"


# Begin Function UserInfo.
Function UserInfo {
    # Process each user individually and set appropriate variables for the user object's properties.
    foreach ( $user in $Allusers ) {
        
        # Set global variables that will be used to determine what information the specified user will get.  
        $userName = $user.Name
        $department = ($user.canonicalname -split '/')[6]
        $locale = ($user.canonicalname -split '/')[5]
        $region = ($user.canonicalname -split '/')[4]

        # Sets the newDeparment variable based on the $department variable above, but formats it in a readable way.  E.X.: TechSupport becomes Tech Support.  If the user's $department variable contains Sales, then make their department 'Sales'.  E.X.: SalesEngineer will be Sales, not Sales Engineer.
        $newDepartment = $department | ForEach-Object { if ($_.Length -gt 3) { $_ -csplit '(?=[A-Z])' -ne '' -join ' ' } else { $department } }
        if ( $newDepartment -match "Sales" ) {
            $newDepartment = "Sales"
        }
       
        # Setting the user's department property.
        if ($user.Department -ne $newDepartment) {
            # Writes to the log/debug file (set by the scheduled task argument) stating if the department property changed for the specific user.
            Set-ADUser -Identity $user -Department $newDepartment
              if($?) {
                if ($debug -eq 1 ) {
                    Write-Output "Set $($userName)'s Department: $newDepartment"
                }
            }
        }

        # Set each user's information for the email signature based the user's locale.
        If ( ($locale -like "Utah") -or ($locale -like "USA-Remote") ) {
            $Company = "StorageCraft Technology Corporation"
            $StreetAddress = "380 Data Drive Suite 300"
            $POBox = $null     
            $City = "Draper" 
            $State = "Utah" 
            $PostalCode = "84020" 
            $HomePage = "https://storagecraft.com"
        }
        If ($locale -like "Wisconsin") {
            $Company = "StorageCraft Technology Corporation"
            $StreetAddress = "1402 Pankratz Street" 
            $POBox = "Suite 104"
            $City = "Madison" 
            $State = "Wisconsin" 
            $PostalCode = "53704" 
            $HomePage = "https://storagecraft.com"
        }  
        If ($locale -like "Asia") {
            $Company = "StorageCraft Pte Ltd"
            $StreetAddress = "1 Harbourfront Place"
            $POBox = "Harbourfront Tower One" 
            $City = "Level 04-01" 
            $State = "Singapore" 
            $PostalCode = "098633" 
            $HomePage = "http://storagecraft.sg"
        }
        If ($locale -like "Portugal") {
            $Company = "StorageCraft Technology Portugal"
            $StreetAddress = "Edifício Lisboa Oriente" 
            $POBox = $null
            $City = "Av. Infante D. Henrique, nº 333, 3º Piso, Escritório 36" 
            $State = "Lisboa" 
            $PostalCode = "Portugal" 
            $HomePage = "www.storagecraft.com/pt"
        }
        If ($locale -like "Japan") {
            $Company = "StorageCraft Technology GK"
            $StreetAddress = "1-1-23 Toranomon" 
            $POBox = $null
            $City = "Minato-ku" 
            $State = "Tokyo" 
            $PostalCode = "105-0001" 
            $HomePage = "https://storagecraft.co.jp"
        } 
        If ($locale -like "Ireland") {
            $Company = "StorageCraft Technology"
            $StreetAddress = "Tellengana House" 
            $POBox = $null
            $City = "Blackrock Rd." 
            $State = "Cork" 
            $PostalCode = "Ireland" 
            $HomePage = "https://storagecraft.eu"
        }
        If ($locale -like "Europe") {
            $Company = "StorageCraft Technology"
            $StreetAddress = "Tellengana House" 
            $POBox = $null
            $City = "Blackrock Rd." 
            $State = "Cork" 
            $PostalCode = "Ireland" 
            $HomePage = "https://storagecraft.eu"
            If ($user.Office -like "Remote / Germany"){
                $Company = "StorageCraft Technologie GmbH"
                $StreetAddress = "Westend Straße 28" 
                $POBox = $null
                $City = "60325 Frankfurt am Main" 
                $State = "Germany" 
                $PostalCode = $null 
                $HomePage = "https://www.storagecraft.com/de"
            }
            If ($user.Office -like "Remote / UK"){
                $Company = "StorageCraft Technology Ltd"
                $StreetAddress = "5th Floor" 
                $POBox = "6 St. Andrew Street"
                $City = "London" 
                $State = "EC4A 3AE" 
                $PostalCode = "United Kingdom"
                $HomePage = "https://www.storagecraft.com/uk/"
            }
            If ($user.Office -like "Remote / Italy"){
                $Company = "StorageCraft Italia, Slr"
                $StreetAddress = "Via Santa Maria Fulcorina 2" 
                $POBox = $null
                $City = "Milano" 
                $State = $null 
                $PostalCode = $null
                $HomePage = "https://www.storagecraft.com/it"
            }
            If ($user.Office -like "Remote / Netherlands"){
                $Company = "StorageCraft Nederland B.V."
                $StreetAddress = "Prins Hendriklaan 26" 
                $POBox = $null
                $City = "1075 BD Amsterdam" 
                $State = "The Netherlands" 
                $PostalCode = $null
                $HomePage = "https://www.storagecraft.com/nl"
            }
        } 

       If ($locale -like "Canada") {
            $Company = "StorageCraft Technology Corporation"
            $StreetAddress = "1300-1500 Georgia Street West" 
            $POBox = $null
            $City = "Vancouver" 
            $State = "BC" 
            $PostalCode = "V6G 2Z6" 
            $HomePage = "https://storagecraft.com"            
        }         
        If ($locale -like "Australia") {
            $Company = "StorageCraft Indo-Pacific Pty Ltd"
            $StreetAddress = "13.02, 201 Kent Street" 
            $POBox = $null
            $City = "Sydney, NSW" 
            $State = "Australia" 
            $PostalCode = "2000" 
            $HomePage = "https://storagecraft.com.au"
        } 
        If ($locale -like "Australia-Remote") {
            $Company = "StorageCraft Indo-Pacific Pty Ltd"
            $StreetAddress = "13.02, 201 Kent Street" 
            $POBox = $null
            $City = "Sydney, NSW" 
            $State = "Australia" 
            $PostalCode = "2000" 
            $HomePage = "https://storagecraft.com.au"
            If ($user.office -like "Remote / New Zealand") {
                $HomePage = "http://storagecraft.co.nz"
            }
        }

        # If a user is in Sales or Marketing and in Americas region change their home page to be the CloudBackup web site, instead of the default STC landing page.  
        If (($region -like "Americas") -and (($user.Department -like "Sales*") -or ($user.Department -like "Marketing"))) {
            $HomePage = "https://www.storagecraft.com/trials/cloud-backup"
        }    
        
        # Only set the below user properties if the specific property needs to change.
            #$user.Name
            ChangeUserInfo $user $userName "-Company" $user.Company $Company
            ChangeUserInfo $user $userName "-StreetAddress" $user.StreetAddress $StreetAddress
            ChangeUserInfo $user $userName "-POBox" $user.POBox $POBox
            ChangeUserInfo $user $userName "-City" $user.City $City
            ChangeUserInfo $user $userName "-State" $user.State $State
            ChangeUserInfo $user $userName "-PostalCode" $user.PostalCode $PostalCode
            ChangeUserInfo $user $userName "-HomePage" $user.HomePage $HomePage

            Set-ADUser -Identity $user -clear "extensionAttribute1"
            #ChangeUserInfo $user $userName "-extensionAttribute1" $user.extensionAttribute1 $HomePage       
    }
}
# close function UserInfo

# Run UserInfo Function
UserInfo

# Log file formatting...
logging "End Script"

<#
We would only use the following for setting the extensionAttribute1 property for Exclaimer Cloud.  Exclaimer could stupidly doesn't grab the -HomePage property from AD, but it does grab the extensionAttributes.
So right now I have this turned off since we aren't using Exclaimer cloud right now. 
Set-ADUser -Identity $user -clear "extensionAttribute1"
Set-ADUser -Identity $user -add @{extensionAttribute1=$HomePage}
#>