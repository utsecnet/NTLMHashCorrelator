﻿<#
            Set-ADUser -Identity $user -Company $Company
            # Writes to the log/debug file (set by the scheduled task argument) stating if the specifed property changed for the specified user.
            if($?) {
               if ($debug -eq 1 ) {
                   Write-Output "Changed $($user.Name)'s company from $($user.Company) to: $Company"
               }
            }
         #}
         #if ( $user.StreetAddress -ne $StreetAddress ) {
            ChangeUserInfo $user $userName "StreetAddress" $user.StreetAddress $StreetAddress
            <#Set-ADUser -Identity $user -StreetAddress $StreetAddress
            # Writes to the log/debug file (set by the scheduled task argument) stating if the specifed property changed for the specified user.
            if($?) {
               if ($debug -eq 1 ) {
                   Write-Output "Changed $($user.Name)'s street address from $($user.StreetAddress) to: $StreetAddress"
               }
            }
         }
         if ( $user.POBox -ne $POBox ) {
            ChangeUserInfo $user $userName "POBox" $POBox
            Set-ADUser -Identity $user -POBox $POBox
            #Writes to the log/debug file (set by the scheduled task argument) stating if the specifed property changed for the specified user.
            if($?) {
               if ($debug -eq 1 ) {
                   Write-Output "Changed $($user.Name)'s POBox from $($user.POBox) to: $POBox"
               }
            }
         }
         if ( $user.City -ne $City ) {
            Set-ADUser -Identity $user -City $City
            # Writes to the log/debug file (set by the scheduled task argument) stating if the specifed property changed for the specified user.
            if($?) {
               if ($debug -eq 1 ) {
                   Write-Output "Changed $($user.Name)'s city from $($user.City) to: $City"
               }
            }
         }
         if ( $user.State -ne $State ) {
            Set-ADUser -Identity $user -State $State
            #Writes to the log/debug file (set by the scheduled task argument) stating if the specifed property changed for the specified user.
            if($?) {
               if ($debug -eq 1 ) {
                   Write-Output "Changed $($user.Name)'s state from $($user.State) to: $State"
               }
            }
         }
         if ( $user.PostalCode -ne $PostalCode ) {
            Set-ADUser -Identity $user -PostalCode $PostalCode
            # Writes to the log/debug file (set by the scheduled task argument) stating if the specifed property changed for the specified user.
            if($?) {
               if ($debug -eq 1 ) {
                   Write-Output "Changed $($user.Name)'s PostalCode from $($user.PostalCode) to: $PostalCode"
               }
            }
         }
         if ( $user.HomePage -ne $HomePage ) {
            Set-ADUser -Identity $user -HomePage $HomePage
            # Writes to the log/debug file (set by the scheduled task argument) stating if the specifed property changed for the specified user.
            if($?) {
               if ($debug -eq 1 ) {
                   Write-Output "Changed $($user.Name)'s Home Page from $($user.HomePage) to: $HomePage"
               }
            }
         }
         #Currently we have to use the extenstionAttribue to set the webpage for signatures.  Exclaimer Cloud doesn't pull the HomePage AD Property like the on prem Exclaimer does. It does pull the extensionAttributes so we will use extensionAttribute1 to set the hyperlinks in the email signature
         if ( $user.extensionAttribute1 -ne $HomePage ) {
            Set-ADUser -Identity $user -clear "extensionAttribute1"
            Set-ADUser -Identity $user -add @{extensionAttribute1=$HomePage}
            # Writes to the log/debug file (set by the scheduled task argument) stating if the specifed property changed for the specified user.
            if($?) {
               if ($debug -eq 1 ) {
                   Write-Output "Changed $($user.Name)'s extensionAttribute1 from $($user.extensionAttribute1) to: $HomePage"
               }
            }
         }#>   