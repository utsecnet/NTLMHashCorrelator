﻿<#
.SYNOPSIS
	This script was designed to be called by the NSClient installed on a Windows IIS Server.
	It will return "Critical" if specified website is not started, "Warning" if the specified
    website is in a starting/stopping state.  It can also run standalone with or without 
    parameters for informational purposes.
.DESCRIPTION
	This script was designed to be called by the NSClient installed on a Windows IIS Server.
	It will return "Critical" if specified website is not started, "Warning" if the specified
    website is in a starting/stopping state.  It can also run standalone with or without 
    parameters for informational purposes.
.PARAMETER siteName
	Optional - define a single web site in IIS.  Sites with spaces must be double-quoted.
	Default: all
	Example: "Default Web Site"
.EXAMPLE
	If using standalone:
        >.\check_iis_site_state.ps1 all
        This will evaluate all IIS web sites and return a CRITICAL if any of the sites are not in
        a started state.

        >.\check_iis_site_state.ps1 Store
        This will check the specified "Store" site.  If it is started it will return OK.  Any other
        state will return CRITICAL

    If using with NRPE:

.NOTES
	NAME:	check_iis_site_state.ps1
	AUTHOR:	Rich Johnson
	DATE:	2016-11-01
	EMAIL:  rich.johnson@storagecraft.com
	REQUIREMENTS:
	- NSCLient++ isntalled, functioning, and correctly communicating with your monitoring server on
	the DHCP server to be checked
	- IIS Server role installed and functioning with at least one active and working web site
	Change Log:
	    2016-11-01 - Initial creation
#>

Param (
	$webSite = "all"
)

# get access to the IIS management cmdlets
If (!(Get-module WebAdministration )) {
    Import-Module WebAdministration
}

$siteNames = get-website | foreach-object { $_.name }

if (($webSite -ne "all") -and ( $siteNames -notcontains $webSite )) {
    Write-Output "Critical: The site you specified does not exist! Check your spelling."
    $status = "Crit"
}

# Process all websites
if ( $webSite -eq "all" ) {
    ForEach ( $site in Get-WebSite ) {
        if ( $site.State -ne "Started" ) {
            Write-Output "Critical: $($site.name) is not started!"
            $status = "Crit"
        }
        else {
            $message = "OK: All sites are started."
        }
    }
}
# Process explicit website
else {
    foreach ( $site in Get-WebSite | where { $_.Name -eq $webSite } ) {
    
        if ( $site.State -ne "Started" ) {
            Write-Output "$($site.name) is not started!"
            $status = "Crit"
        }
        else {
            $message = "OK: $($site.name) is $($site.state)."
        }
    }
}

if ( $status -eq "Crit" ) { exit 2 }
Write-Output $message
exit 0