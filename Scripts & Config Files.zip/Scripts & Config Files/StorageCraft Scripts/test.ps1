﻿# set computername
$computername = $env:computername
$uploadedFile = "\\stc-file\stc\it\spx\endpoint logs\bbb---$computername.txt"
$localFile = "c:\programdata\test.txt"

# If $uploadedFile exists, exit
If (Test-Path $uploadedFile){
    exit
}

# search for file
Get-WMIObject Win32_LogicalDisk -filter “DriveType = 3” |
    Select-Object DeviceID |
    ForEach-Object { Get-Childitem ($_.DeviceID + “\”) -include *.torrent -recurse } >> $localFile

# check that c:\programdata\test.txt exists
$computername = $env:computername
If (Test-Path $localFile){
    if((Get-Item $localFile).Length -gt 0kb) {
        Copy-Item $localFile $uploadedFile
    }
}

# delete the local file
Remove-Item C:\ProgramData\test2.txt