If (!(Get-module ActiveDirectory )) {
    Import-Module ActiveDirectory
}

# URL to your System Frontier installation API
$url = "http://10.1.10.20/api/api.aspx"

$allServers = get-adcomputer -filter * -SearchBase "OU=Computers,OU=EXT,DC=ext,DC=local" -properties * | ? {$_.operatingsystem -like "*Windows*"}

$allServers | ForEach-Object {
    
	$_.Name
	$target = "computer"
	$action = "import"
	$hostname = $_.Name
	$domain = "EXT.LOCAL"
	$status = "Active"
	$environment = "Prod"
	$description = $_.Name
	$ipv4address = "0.0.0.0"
	$ipInfo = Test-Connection $hostname -Count 1 -ErrorAction SilentlyContinue
	
    if ($ipInfo -ne $null) { $ipv4address = $ipInfo.IPv4Address.ToString() }
	$computerInfo = $null
	$biosInfo = $null
	$osInfo = $null
	$computerInfo = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $hostname -ErrorAction SilentlyContinue
	$biosInfo = Get-WmiObject -Class Win32_Bios -ComputerName $hostname -ErrorAction SilentlyContinue
	$osInfo = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $hostname -ErrorAction SilentlyContinue
	$postData = New-Object System.Collections.Specialized.NameValueCollection

	$postData.Add("target", $target)
	$postData.Add("action", $action)
	$postData.Add("hostname", $hostname)
	$postData.Add("domain", $domain)
	$postData.Add("status", $status)
	$postData.Add("environment", $environment)
	$postData.Add("description", $description)
	$postData.Add("IPv4Address", $ipv4address)

	if ($computerInfo -ne $null) {
		$postData.Add("Manufacturer", $computerInfo.Manufacturer)
		$postData.Add("Model", $computerInfo.Model)
		$postData.Add("Memory", [math]::truncate($computerInfo.TotalPhysicalMemory/1MB))
	}

	if ($biosInfo -ne $null) {
		$postData.Add("SerialNumber", $biosInfo.SerialNumber)
	}

	if ($osInfo -ne $null) {
		$postData.Add("OperatingSystem", $osInfo.Caption)
	}

	# Submit the operation to the SF API using the hashed stc\sfrontier user's credentials	
	$webClient = New-Object "System.Net.WebClient"
	$User = "stc\sfrontier"

    # To generate the encrypted password file, you must login to the server on which this script is run as a scheduled task as the sfrontier user (or as the user who is running the schedueld task) and run the following command:
    # 
    # "password" | ConvertTo-SecureString -asplaintext -force | convertfrom-securestring | out-file c:\users\sfrontier\documents\SFDomainPW.txt
    #
    # Where password is the password for the stc\sfrontier user account.


	$Creds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, (Get-Content "C:\Users\sfrontier\Documents\SFDomainPW.txt" | ConvertTo-SecureString)
	$webClient.Credentials = $Creds
	$webClient.Headers.Add("Content-Type", "application/x-www-form-urlencoded")

	$result = $webClient.UploadValues($url, $postData)
	# Append results for this record to a log file
	$out = [System.Text.Encoding]::ASCII.GetString($result)
	$out | Out-File -FilePath C:\Users\sfrontier\Documents\sf-import.txt -Append
	#Output to the screen
	"  Result: $($out)"
}