# -*- coding: utf-8 -*-
# Copyright (C) 2015 StorageCraft Technology Corporation. All rights reserved.
# This source code (including its associated software) is owned by
# StorageCraft Technology Corporation and is protected by United States and
# international intellectual property law, including copyright laws, patent
# laws, and treaty provisions.
""" Configure SPX with a backup job.

SPX must already be installed with the service running.

Run with -h for help.
"""

import argparse
import base64
import json
import logging
import os
import random
import smtplib
import sys
import requests
from email.mime.text import MIMEText

SERVER_ENCRYPTION_PASSWORD = '50l1d50urc35af3'
SMTP_HOST = 'mail.storagecraft.com'
SMTP_TO = 'helpdesk@storagecraft.com'
SMTP_FROM_SERVER = 'STC-Backup@storagecraft.com'
SMTP_FROM_WKS = 'STC-Backup-WKS@storagecraft.com'

COMPUTER_NAME = os.environ['COMPUTERNAME']
PROGRAM_DATA = os.environ.get('ProgramData', r'C:\ProgramData')
CONFIG_FILE = os.path.join(PROGRAM_DATA, 'StorageCraft', 'spx', 'spx_config.json')
#LOG_FILE = os.path.join(PROGRAM_DATA, 'installSPX.txt')
LOG_FILE = os.path.join(r'\\stc-file\stc\it\SPX\Endpoint Logs', COMPUTER_NAME + '.txt')
BASE_URL = 'https://localhost:13581/spx/'

s = requests.Session()
s.verify = False

logger = logging.getLogger()

def main():
    args = parse_args()
    setup_logging()
    try:
        job_name = 'STC {} - {}'.format(args.platform, COMPUTER_NAME)
        token = authenticate()
        s.headers['Authorization'] = 'Token ' + token

        jobs = get_jobs()
        if already_configured(job_name, jobs):
            logger.info('Expected job already exists.')
            sys.exit(3)

        delete_jobs(jobs)
        destinations = get_destinations()
        delete_destinations(destinations)

        dest_id = create_destination(args.backup_path)
        logger.info('Destination path will be: ' + args.backup_path)
        logger.info('Will backup system volumes')
        password = get_encryption_password(args.platform)
        days = get_scheduled_days(args.platform)
        start, end = get_scheduled_time()
        repeats = get_scheduled_repeat(args.platform)

        job = dict(
            name=job_name,
            destination=dest_id,
            settings=dict(
                comment='StorageCraft IT managed backup job',
                compression=5,          # 0 = none, 5 = standard, 6 = best
                encryption=4,           # 4 = aes 256
                enc_password=password,
                sch_type=4,             # 4 = continuous incremental
                io_throttle=50,
            ),
            schedule=dict(
                rules=[dict(
                    start=start,
                    end=end,
                    frequency=0,        # 0 = weekly, 1 = monthly
                    repeats=repeats,
                    mode=1,             # 0 = full, 1 = incremental
                    offsets=dict(days=days),
                )],
            ),
            volume_scheme=1,            # 0 = all, 1 = system only, 2 = data only
        )

        create_job(job)
        logger.info('Backup job created successfully')
        notify_helpdesk(args.platform, password)

    except Exception:
        logger.exception('Error configuring SPX; rolling back any job creation')
        # If something goes wrong, delete any jobs. Otherwise, we'll have a
        # job for which we don't know the encryption key, and if we try to
        # run this script again, it'll exit because the job already exists.
        try:
            jobs = get_jobs()
            delete_jobs(jobs)
        except:
            logger.exception('Failed to roll back job creation')
    finally:
        logger.info('Exiting script'.center(50, '-'))

def parse_args():
    parser = argparse.ArgumentParser(description='SPX job configuration script')
    parser.add_argument('backup_path', help='Network path to the backup destination')
    parser.add_argument('platform', help='Machine platform', choices=['WKS', 'Server'])
    return parser.parse_args()

def setup_logging():
    log_dir = os.path.dirname(LOG_FILE)
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    config = dict(
        format='%(asctime)s %(levelname)1.1s %(message)s',
        level=logging.DEBUG,
        filename=LOG_FILE
    )
    logging.basicConfig(**config)
    script_name = os.path.split(__file__)[1]
    logger.info(script_name.center(50, '='))

def already_configured(job_name, jobs):
    for job in jobs:
        if job['name'] == job_name:
            return True
    return False

def get_encryption_password(platform):
    if platform == 'WKS':
        import random
        #random_bytes = os.urandom(33)  # 33 just so b64encode w/o padding
        #return base64.b64encode(random_bytes)
        return str(random.randint(10000000, 99999999))
    else:
        return SERVER_ENCRYPTION_PASSWORD

def get_scheduled_days(platform):
    # 0 = Sun, 1 = Mon, etc.
    days = [1, 2, 3, 4, 5] if platform == 'WKS' else [0, 1, 2, 3, 4, 5, 6]
    logger.info('Scheduled days will be {}'.format(days))
    return days

def get_scheduled_time():
    minutes = random.choice(range(60))
    start = 'T00:{:02}:00'.format(minutes)
    end = 'T23:59:00'
    logger.info('Scheduled time will be {} - {}'.format(start, end))
    return start, end

def get_scheduled_repeat(platform):
    repeats = 90 if platform == 'WKS' else 60
    logger.info('Scheduled repeat interval will be {} minutes'.format(repeats))
    return repeats

def notify_helpdesk(platform, encryption_password):
    if platform == 'WKS':
        sender = SMTP_FROM_WKS
        text = encryption_password
    else:
        sender = SMTP_FROM_SERVER
        text = ('Please set up managed folder in ImageManager '
                'and set up replication to stc-backup-c7!')
    msg = MIMEText(text)
    msg['Subject'] = COMPUTER_NAME + ' Backup Job Created'
    msg['From'] = sender
    msg['To'] = SMTP_TO

    mail_server = smtplib.SMTP(SMTP_HOST)
    mail_server.sendmail(sender, [SMTP_TO], msg.as_string())
    mail_server.quit()
    logger.info('Email sent to ' + SMTP_TO)

# Generic helpers ------------------------------------------------------------

def authenticate():
    # Use the admin token from the machine to talk to the API.
    with open(CONFIG_FILE, 'r') as f:
        config = json.load(f)
        return config['admin_token']

def get_jobs():
    r = s.get(url('v1/backup'))
    if r.status_code != requests.codes.ok:
        raise Exception('Getting jobs failed: {}'.format(r.status_code))
    return r.json()

def delete_jobs(jobs):
    logger.info('Deleting any existing jobs...')
    for job in jobs:
        delete_job(job)

def delete_job(job):
    r = s.delete(url('v1/backup/' + job['uuid']))
    if r.status_code != requests.codes.ok:
        logger.warning('Deleting job {} failed: {}'.format(job.name, r.status_code))

def get_destinations():
    r = s.get(url('v1/destination'))
    if r.status_code != requests.codes.ok:
        raise Exception('Getting destinations failed: {}'.format(r.status_code))
    return r.json()

def create_destination(path):
    payload = {'name': 'Backups', 'path': path, 'store_type': 1}
    headers = {'Content-Type': 'application/json'}
    r = s.post(url('v1/destination'), data=json.dumps(payload), headers=headers)
    if r.status_code != requests.codes.created:
        raise Exception('Creating destination failed: {}\n{}'.format(r.status_code, r.text))
    return r.text

def delete_destinations(dests):
    logger.info('Deleting any existing destinations...')
    for destination in dests:
        delete_destination(destination)

def delete_destination(dest):
    r = s.delete(url('v1/destination/' + dest['uuid']))
    if r.status_code != requests.codes.ok:
        logger.warning('Deleting destination {} failed: {}'.format(dest['name'], r.status_code))

def create_job(payload):
    headers = {'Content-Type': 'application/json'}
    r = s.post(url('v1/backup'), data=json.dumps(payload), headers=headers)
    if r.status_code != requests.codes.created:
        raise Exception('Creating job failed: {}\n{}'.format(r.status_code, r.text))
    return r.text

def url(relative_path):
    return BASE_URL + relative_path

if __name__ == '__main__':
    main()