﻿<#
NOTES
    modifyServiceACL.ps1
    AUthor: Rich Johnson | StorageCraft Technology Corporation

DESCRIPTION 
    Adds an ACE allowing a pre-defined user or group to start, stop, and restart a given service.
    Currently set to allow the group, STC-AllServers--ServiceControl access to all services on
    all servers in the stc.local domain.

CHANGE LOG
    2016-03-15 - Initial Creation
#>

$domain = "stc"
$user = "STC-AllServers--ServiceControl"
#$user = "UT-NOC-Users"

Get-Service | ForEach-Object {
    $serviceName = $_.Name
    $serviceName
    # apply the ACE
    #& "\\stc-file\stc\it\Windows Resource Kits\subinacl.exe" /service "$_" /grant=$domain\$user=STOP
    & "C:\Users\Admin\Documents\subinacl.exe" /service "$_" /grant=$domain\$user=STOP

    #Read-Host "Press ENTER"

    # uncomment if you need to undo changes
    #& "\\stc-file\stc\it\Windows Resource Kits\subinacl.exe" /service $_ /revoke=$domain\$user
}