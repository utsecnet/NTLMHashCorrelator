﻿<#
.SYNOPSIS
    This script manages all aspects of ShadowControl from installation, to subscribing and ensuring we stay subscribed to the right appliance.
    This script is called via a scheduled task or an immediate task (via GPO) with the following details:
        General Tab
            - runas: SYSTEM (does not require 'run as highest privileges'
        Actions Tab
            - Program/script: powershell.exe
            - Arguments: -executionpolicy bypass -command \\server\share\installcmd.ps1 <org>

.DESCRIPTION 
    - Checks if installed, if not it installs and verifies successful installation
    - Checks service is running, if not it starts it and verifies successful start
    - Checks if endpoint is up to date, if not it updates and verifies successful update
        - The ShadowControl appliance normally does keep the endpoint up to date, but we often refresh the appliance for testing new releases and
          opt to not backup and restore the database, but prefer to start fresh.
    - Check if subscribed to the managed appliance, if not it subscribes and verifies successful subscription

.PARAMETER location
    Summary: provide the site as created in the appliance.
    Required: Yes 
    Example: UT-Draper

.Example
    >.\installcmd UT-Draper
    This will cause the endpoint to subscribe to the site UT-Draper

.NOTES
    NAME: installCMD.ps1
    AUTHOR: Rich Johnson
    EMAIL: rich.johnson@storagecraft.com
    REQUIREMENTS: coming soon...
    Change Log:
        2017-05-12 - Fixed a bug where using platform Server (capitol S) was causing servers to fail when subscribing.  Switched to lower case.
                   - Added a tag for servers
        2017-05-12 - Initial creation 
#>

############
# Parameters
############

# ShadowControl site the endpoint will subscribe to
param([string]$site)

############
# Functions
############

# All actions are logged by calling this function
function logging ($level, $text) {
    if ($debug -ne "on" -and $level -eq "D") {
        return
    }
    $timeStamp = get-date -Format "yyyy-MM-dd HH:mm:ss.fff"

    if ($blurb -ne "yes") {
        # Override the existing log file so it does not grow out of control
        Write-Output "$timeStamp I New log created" > $logLocation
        $script:blurb = "yes"
    }

    Write-Output "$timeStamp $level $text" >> $logLocation
}

# Check if a service exists
function checkServiceExists ($serviceName) {
    # Check if service exists
    if (Get-Service $serviceName -EA SilentlyContinue) {
        $serviceExists = $true
    }
    else {
        $serviceExists = $false
    }
    logging "D" "serviceExists: $serviceExists"
    return $serviceExists
}

# Check if a service is running or not
function checkServiceStatus ($serviceName) {
    if ($(get-service $serviceName).Status -eq "Running") {
        $serviceStatus = $true
    }
    else {
        $serviceStatus = $false
    }
    logging "D" "serviceStatus: $serviceStatus"
    return $serviceStatus
}

# Check if product is up to date
function checkUpToDate ($binaryPath, $installFilePath) {
    # Check installed version
    $script:localVersion = & $binaryPath version
    logging "D" "localVersion: $localVersion"

    # Check hosted version
    $comObjWI = New-Object -ComObject WindowsInstaller.Installer
    $msiDatabase = $comObjWI.GetType().InvokeMember("OpenDatabase","InvokeMethod",$Null,$comObjWI,@($installFilePath,0))
    $query = "SELECT Value FROM Property WHERE Property = 'ProductVersion'"
    $view = $MSIDatabase.GetType().InvokeMember("OpenView","InvokeMethod",$null,$msiDatabase,($query))
    $view.GetType().InvokeMember("Execute", "InvokeMethod", $null, $view, $null)
    $record = $View.GetType().InvokeMember("Fetch","InvokeMethod",$null,$view,$null)
    $script:hostedVersion = $Record.GetType().InvokeMember("StringData","GetProperty",$null,$record,1)
    logging "D" "hostedVersion: $hostedVersion"

    # Compair versions
    if ($localVersion -ge $hostedVersion) {
        $upToDate = $true
    }
    else {
        $upToDate = $false
    }
    logging "D" "updated: $upToDate"
    return $upToDate
}

# Check subscription status
function checkSubscribed ($applianceDNS) {
    # Check which appliance the endpoint is subscribed to
    $script:appl_addr = (((& "C:\Program Files (x86)\StorageCraft\cmd\stccmd.exe" status) -split (': ')) -split '\n')[3]
    logging "D" "appl_addr: $appl_addr"

    return ($applianceDNS -eq $appl_addr)
}

function installShadowControl {
    # Check that the path to the install file exists and install
    if (Test-Path $installFilePath) {
        logging "D" "install command: msiexec /qn /lvoicewarmupx $installLog /package $installFilePath REBOOT=ReallySuppress"
        Start-Process -FilePath msiexec -ArgumentList /qn, /lvoicewarmupx, $installLog, /package, $installFilePath, REBOOT=ReallySuppress -Wait
    }
    else {
        logging "E" "$installFilePath does not exist"
        #exit
    }
}

######################
# Set global variables
######################

# Location where this script will log to
# This is different than the msiexec installation log file, which you specify in the install command
$logLocation = "\\stc-file\stc\it\cmd\endpoint logs\$env:computername.txt"

# Turn this to on if you want additional debug logging.  Off will overwrite On if you uncomment the <debug = "off"> line.
# Debug logging will show you the value of all variables so you can see if varable logic problems exist
$debug = "on"
#$debug = "off"

# A stupid workaround to force the log file to clear and start a new file each time.
$blurb = "no"

# Computer Name
$computerName = $env:computername
#$computerName = "s-ut-wsm"    # Used for testing other machines
logging "D" "computername: $computername"

# Distinguished Name - cant use the activedirectory module, as all computers in the domain do not have this installed
$filter = "(&(objectCategory=computer)(objectClass=computer)(cn=$computerName))"
$dn = ([adsisearcher]$filter).FindOne().Properties.distinguishedname
logging "D" "dn: $dn"

# Tag, Site, and Platform 
if ($dn -like "*Workstations*") {
    $tag = ($dn -split '[,\=]')[3]
    if ($dn -like "*Laptops*") { $platform = "laptop"}
    if ($dn -like "*Desktops*") { $platform = "desktop"}
    if ($dn -like "*VM*") { $platform = "virtual"}
}
elseif ($dn -like "*Servers*" -or $dn -like "*Domain Controllers*") {
    $platform = "server"
    $tag = "Server"
}
logging "D" "platform: $platform"
logging "D" "tag: $tag"

# Immediatly exit if VM or Engineering
if ($dn -like "*OU=VM*") {
    logging "I" "Endpoint is a VM.  We don't backup VMs."
    exit
}

if ($dn -like "*OU=Engineering*") {
    logging "I" "Endpoint is in Engineering.  We don't controll Engineering's backups."
    exit
}

# Name of the ShadowControl Service
$serviceName = "stc_endpt_svc"
logging "D" "serviceName: $serviceName"

# ShadowControl installation directory
$installationPath = "C:\Program Files (x86)\StorageCraft\CMD"
logging "D" "installationPath: $installationPath"

# Name of the ShadowControl binary
$binaryName = "stccmd.exe"
logging "D" "binaryName: $binaryName"

# Name of ShadowControl API
$api = "stccmd.exe"

# Full path to the ShadowControl binary
$binaryPath = "$installationPath\$binaryName";
logging "D" "binaryPath: $binaryPath"

# Path to the msi install logs
$installLog = "$env:programdata\installcmd.txt"
logging "D" "installLog: $installLog"

# Name of the ShadowControl Installer
$installFile = "ShadowControl.msi"
logging "D" "installFile: $installFile"

# Name of the server where the installation files are located
if ($site -eq "UT_Draper" -or $site -eq "CA_Sunnyvale" -or $site -eq "WI_Madison") {
    $fileServer = "stc-file"
}
elseif ($site -eq "IE_Cork") {
    $fileServer = "stc-ie-file"
}
elseif ($site -eq "AU_Sydney") {
    $fileServer = "s-au-file"
}
else {
    logging "E" "Uh Oh... No site file server defined!"
    exit
}
logging "D" "fileServer: $fileServer"

# DNS name of the ShadowControl appliance
$applianceDNS = "s-ut-shadowcontrol"
logging "D" "applianceDNS: $applianceDNS"

# Full path to the ShadowControll Installer
$installFilePath = "\\$fileServer\stc\it\cmd\$installFile"
logging "D" "installFilePath: $installFilePath"

# Subscription token used to subscribe to an appliance
$token = "8676862d39074ccab07451564d5b9c9e"
logging "D" "token: $token"

# Appliance Organization
$org = "STC:$site"
logging "D" "org: $org"

##################
# Aaaaaaad ACTION!
##################

try {
    # Verify we have received one parameter from the schedueld task that calls this script
    if (!$site) { 
        logging "E" "Argument 1 (site) does not exist!"
        exit
    }

    # Is ShadowControl agent installed?
    ###################################
    if ($(checkServiceExists $serviceName) -eq $true) {
        logging "I" "ShadowControl Agent is installed."
    }
    else {
        logging "I" "ShadowControl agent is not currently installed."

        # Install
        installShadowControl

        # Did it install correctly?
        if ($(checkServiceExists $serviceName) -eq $true) {
            logging "I" "ShadowControl Agent installed correctly."
        }
        else {
            logging "E" "ShadowControl agent did not install correctly. Service $serviceName still not found."
        }
    }

    # Is the ShadowControl agent service started?
    #############################################
    if ($(checkServiceStatus $serviceName) -eq $true) {
        logging "I" "Service $serviceName is running."
    }
    else {
        logging "I" "Service $serviceName is not running."

        # Start Service
        Start-Service $serviceName

        # Did it start correctly?
        if ($(checkServiceStatus $serviceName) -eq $true) {
            logging "I" "Successfully started service $serviceName"
        }
        else {
            logging "E" "Failed to start service $serviceName."
        }
    }

    # Is ShadowControl agent up to date?
    ####################################
    if ($(checkUpToDate $binaryPath $installFilePath) -eq $true) {
        logging "I" "Shadow Control version $localVersion is up to date."
    }
    else {
        logging "I" "Shadow Control version $localVersion is out of date. Will update to $hostedVersion."
    
        # Update
        installShadowControl

        # Did it update correctly?
        if ($(checkUpToDate $binaryPath $installFilePath) -eq $true) {
            logging "I" "ShadowControl was successfully updated to version $localVersion"
        }
        else {
            logging "E" "Failed to update ShadowControl to verion $hostedVersion."
        }
    }

    # Is ShadowControl agent subscribed to correct appliance?
    #########################################################
    if ($(checkSubscribed $applianceDNS) -eq $true) {
        logging "I" "Shadow Control agent is subscribed to the correct appliance: $applianceDNS."
    }
    else {
        logging "I" "Shadow Control agent is not subscribed to $applianceDNS. Currently subcsribed to: $appl_addr"
    
        # Subscribe
        logging "D" "Subscription command: '$binaryPath' subscribe -a $applianceDNS -f -T $token -m $platform -o $org -t $tag"
        cmd.exe /c "$binaryPath" subscribe -a $applianceDNS -f -T $token -m $platform -o $org -t $tag

        # Did it subscribe correctly?
        if ($(checkSubscribed $applianceDNS) -eq $true) {
            logging "I" "Shadow Control agent successfully subscribed to: $applianceDNS."
        }
        else {
            logging "E" "Failed to subscribe to $applianceDNS."
        }
    }
}
catch {
    logging "E" $Error[0]
}
finally {
    logging "I" "Exiting script."
}