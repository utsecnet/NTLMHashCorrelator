<#
.SYNOPSIS
	This script was designed to be called by the NSClient installed on a Windows DHCP Server.
	It will return "Critical" if any of the DHCP scopes (or a specified DHCP scope) is above
 	the critical threshold, "Warning" if above the warning threshold, or "OK" if below the
 	warning threshold.  It can also run standalone with or without parameters for informational
	purposes.
.DESCRIPTION
	This script was designed to be called by the NSClient installed on a Windows DHCP Server.
	It will return "Critical" if any of the DHCP scopes (or a specified DHCP scope) is above
	the critical threshold, "Warning" if above the warning threshhold, or "OK" if below the
	warning threshold.  It can also run standalone with or without parameters for informational
 	purposes.
.PARAMETER scopeID (-s)
	Optional - define a single scope in the format of the subnet ID, or all scopes by using "all"
	Default: all
	Example: 192.168.0.0
	Example: all
.PARAMETER warn (-w)
	Optional - Percentaged of scope IPs used before returning a warning
	Default: 90
.PARAMETER crit (-c)
	Optional - Percentage of scope IPs used before returning a critical
	Default: 98
.EXAMPLE
	If using standalone:
        >.\check_dhcp_scope.ps1
        This will evaluate all DHCP scopes and return a warning or critical if any of the scopes are
        above 90% or 98% full.
        Same

        >.\check_dhcp_scope.ps1 -all -w 50 -c 80
        This will evaluate all DHCP scopes and return a warning or critical if any of the scopes are
        above 50% or 80% full.

        >.\check_dhcp_scope.ps1 -s 192.168.0.0
        This will evaluate the 192.168.0.0 scope and return a warning or critical if is above 90% or
        98% full.

        >.\check_dhcp_scope.ps1 -s 192.168.0.0 -w 50 -c 80
        This will evaluate the 192.168.0.0 scope and return a warning or critical if is above 50% or
        80% full.
    If using with NRPE:

.NOTES
	NAME:	check_dhcp_scopes.ps1
	AUTHOR:	Rich Johnson
	DATE:	2016-07-07
	EMAIL:  rich.johnson@storagecraft.com
	REQUIREMENTS:
	- NSCLient++ isntalled, functioning, and correctly communicating with your monitoring server on
	the DHCP server to be checked
	- DHCP Server role installed and functioning with at least one active and working scope
	Change Log:
	    2016-07-07 - Initial creation
#>

Param (
	$scopeID = "all",
	[validateRange(0,100)][Int]$warn = 90,
	[ValidateRange(0,100)][Int]$crit = 98,
	[string]$verbose
)

$message = ""
$isWarning  = 0
$isCritical = 0

if ( $scopeID -eq "all" ) {
	$activeScopes = Get-DhcpServerv4Scope | Where { $_.State -eq 'Active' }
}
else {
	$activeScopes = Get-DhcpServerv4Scope $scopeID | Where { $_.State -eq 'Active' }
}

# Some comment
$activeScopes | ForEach-Object {

	$scope = $_
	$stats = Get-DhcpServerv4ScopeStatistics $scope.ScopeId

	$used = [Int]$stats.PercentageInUse
	$free = [int]$stats.Free
	$leases = [int]$stats.InUse

	switch ($used) {
		{$_ -ge $crit} { 
			$isCritical = $isCritical + 1
			Write-Output "Critical: $($scope.Name) is $used% used, ($leases leases, $free IP's available.)"
			break
		}
		{$_ -ge $warn} { 
			$isWarning = $isWarning + 1
			Write-Output "Warning: $($scope.Name) is $used% used, ($leases leases, $free IP's available.)"
			break
		}
		{$_ -lt $warn} {
			#Write-Output "OK: $($scope.Name) in good order."
			$message = "OK: Scope(s) are happy."
			break
		}
	}
}

if ($isCritical -gt 0) { exit 2 }
if ($isWarning  -gt 0) { exit 1 }
Write-Output $message
exit 0