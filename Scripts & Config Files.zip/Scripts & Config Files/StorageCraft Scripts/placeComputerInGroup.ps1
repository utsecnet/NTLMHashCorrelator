﻿# PlaceComputerInGroup.ps1
# Written by Brady Young for StorageCraft Technology Corporation
# Last modified 7/10/2015

Import-Module ActiveDirectory 

#First, remove all object in the GPO-Security-ScreenSaverAndScreenLock group
Get-ADGroupMember "GPO-Security-ScreenSaverAndScreenLock" | ForEach-Object {Remove-ADGroupMember "GPO-Security-ScreenSaverAndScreenLock"  $_ -Confirm:$false}

#Search the VM OU for all computer objects and but into an array called Computers
$computers = Get-ADComputer -Filter * -SearchBase "OU=VM,OU=Workstations,OU=STC-Utah,OU=Computers,OU=StorageCraft,DC=stc,DC=local"

#For each computer in the array but that computer in the GPO-Security-ScreenSaverAndScreenLock group
foreach ($computer in $computers)
{
    Add-ADGroupMember "GPO-Security-ScreenSaverAndScreenLock" -member $computer    
}