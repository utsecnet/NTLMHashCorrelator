﻿<#
.SYNOPSIS
    Build user and computer shadow groups in AD.
    shadowGroups.ps1
    AUthor: Rich Johnson | StorageCraft Technology Corporation

.DESCRIPTION
    - Creates shadow groups for computer objects in Active Directory. OU structure is very important.
    - Adds computers to the appropriate groups. Also nests groups.
    - Disables computer objects and moves them to a specified OU if inactive.
    - Creates shadow groups for user objects in Active Directory.  OU structure, again, is very important.
    - Adds users to the appropriate groups. Also nests groups.
    - Adds users to appropriate chat groups for open fire server.
    - Moves all disabled users to the DisabledUsers OU
    - Removes all group membership of disabled user accounts
    - Removes all disabled users from the GAL

.NOTES
    NAME: shadowGroups.ps1
    AUTHOR: Rich Johnson
    EMAIL: rich.johnson@storagecraft.com
    REQUIREMENTS:
    Change Log:
        2016-09-02 - Added DL ShadowGroup function
                   - Rebuilt the User funtion to be more human readable (easy to follow what's happening)
	    2016-06-16 - Added Singapore - SG country code
        2016-06-09 - Creates All-Country-Users group, and adds other groups to these groups based on country/remote
        2016-06-07 - Output data to a logfile
        2016-06-02 - No longer disables computers with a null lastLogonDate (newly created computers) unless it has been null for the spcified days (45 days for local, 265 days for remote).
        2016-06-01 - Move disabled user to Disabled Users OU
                   - Complete re-write on all logic performed on users and groups, decreasing length of time script runs by over 2000%
        2016-05-31 - Added debugging
        2016-05-11 - Process disabled users, remove from GAL and remove all group membership
        2016-05-06 - Chat groups
        2016-02-17 - Initial Creation

    TODO
        Re-write the Computer Shadow Group function to make it more readable and congruent with the new locale/region naming convention
        Move all the other DLs that are specific to departments/projects to new OUs, kinda like how we have Roles OUs under SecurityGroups
        Easily add users/groups to send to DLs without moderation
        All of the DLs on the second tab should allow unauthenticated senders
            -RequireSenderAuthenticationEnabled $true
#>


$server = "stc-ut-dc2"
#$allUsers = "OU=Employees,OU=Users,OU=StorageCraft,DC=stc,DC=local"
#$allGroups = "OU=Groups,OU=StorageCraft,DC=stc,DC=local"

#for each group utah-businesssystems-uers is a member of, add user to that group



$member = "Kevin.Quinn"
$membership = (Get-ADUser $member -Properties memberof).memberof
$memberGroups = (Get-ADGroup -Server $server Utah-BusinessSystems-Users -Properties memberof).memberof


foreach ($group in $memberGroups) {
    $groupname = ($group -split '[,\=]')[1]
    $groupnamecn = "CN=$groupname,"
    if (!($membership -match "$groupnamecn,")) {
        Write-Output "We will add $member to $groupname"

    }
    else {
        Write-Output "We will not add $member to $groupname"
    }







}
