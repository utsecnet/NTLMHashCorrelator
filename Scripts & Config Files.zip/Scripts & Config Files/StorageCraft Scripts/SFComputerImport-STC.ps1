﻿If (!(Get-module ActiveDirectory )) {
    Import-Module ActiveDirectory
}

# URL to your System Frontier installation API
# Example: $url = "http://localhost:8080/api/computer"
$url = "http://10.1.10.20/api/api.aspx"


#'OU=Computers,OU=StorageCraft,DC=stc,DC=local','OU=Domain Controllers,OU=StorageCraft,DC=stc,DC=local' |
#    ForEach-Object {get-adcomputer -Filter "OperatingSystem -like '*XP*'" -Property * -SearchBase $_}

$allServerOUs = Get-ADOrganizationalUnit -SearchBase "DC=stc,DC=local" -Filter {Name -like "*Servers*" -or Name -like "Domain Controllers"}
write-output  $allServerOUs
$allServers = $allServerOUs | ForEach-Object { Get-ADComputer -Filter 'OperatingSystem -like "Windows*"' -SearchBase $_ }

$allServers | ForEach-Object {
    # turn debug "on" or "off"
    $debug = "off"


    if ( $debug -eq "on" ) {
        Write-Output "name: $($_.Name)"
    }
	# Populate required fields (Only for import and add operations. $hostname is the minimum for update operations)
	# Available actions: import, add, update.
	# "import" will always add a new computer if it doesn't exist and 
	# update the first matching one it finds in the database.
	# =========================================================================
	$target = "computer"
	$action = "import"
	$hostname = $_.Name
    $domain = "STC.LOCAL"

    # These fields aren't required for the "update" action
	$status = "Active"
	$environment = "Prod"
	$description = $_.Name
	# =========================================================================
	# End required fields
	
	$ipv4address = "0.0.0.0"
	$ipInfo = Test-Connection $hostname -Count 1 -ErrorAction SilentlyContinue
	if ($ipInfo -ne $null) { 
        $ipv4address = $ipInfo.IPv4Address.ToString() 
    }
    if ( $debug -eq "on" ) {
        Write-Output "    ipv4address: $ipv4address"
    }
	
	$computerInfo = $null
	$biosInfo = $null
	$osInfo = $null

	$computerInfo = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $hostname -ErrorAction SilentlyContinue
	$biosInfo = Get-WmiObject -Class Win32_Bios -ComputerName $hostname -ErrorAction SilentlyContinue
	$osInfo = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $hostname -ErrorAction SilentlyContinue

    if ( $debug -eq "on" ) {
        Write-Output "    computerInfo: $computerInfo"
        Write-Output "    biosInfo: $biosInfo"
        Write-Output "    osInfo: $osInfo"
    }

	# Build the payload to submit to the web api
	$postData = New-Object System.Collections.Specialized.NameValueCollection

	# Required fields...
	$postData.Add("target", $target)
	$postData.Add("action", $action)
	$postData.Add("hostname", $hostname)
    $postData.Add("domain", $domain)
	# End required fields
	
	# These fields aren't required for the "update" action
	$postData.Add("status", $status)
	$postData.Add("environment", $environment)
	$postData.Add("description", $description)

	# Add optional fields
	# NOTE: You can add as many fields as you want here as long as the names correspond 
	#	to column names in the System Frontier database.
	$postData.Add("IPv4Address", $ipv4address)

    if ($computerInfo -ne $null) {
		$postData.Add("Manufacturer", $computerInfo.Manufacturer)
		$postData.Add("Model", $computerInfo.Model)
		$postData.Add("Memory", [math]::truncate($computerInfo.TotalPhysicalMemory/1MB))
	}
	
	if ($biosInfo -ne $null) {
		$postData.Add("SerialNumber", $biosInfo.SerialNumber)
	}

	if ($osInfo -ne $null) {
		$postData.Add("OperatingSystem", $osInfo.Caption)
	}
	
	# Submit the operation to the SF API using the currently logged on user's credentials	
    $webClient = New-Object "System.Net.WebClient"
    $webClient.UseDefaultCredentials = $true
	$webClient.Headers.Add("Content-Type", "application/x-www-form-urlencoded")
    
    if ( $debug -eq "on" ) {
        Write-Output "    url: $url"
        Write-Output "    postdata: $postData"
    }

    $result = $webClient.UploadValues($url, $postData)
	
	# Append results for this record to a log file
	$out = [System.Text.Encoding]::ASCII.GetString($result)
	$out | Out-File -FilePath C:\ProgramData\SystemFrontier-importlog.txt -Append
	
	#Output to the screen
	"Result: $($out)"
}