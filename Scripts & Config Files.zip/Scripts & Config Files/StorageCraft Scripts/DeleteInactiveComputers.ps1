﻿<#
SYNOPSIS 
    This script enumerates computer accounts within a specified OU and performs the following
    actions on each object within:
    Disables computer(if not already), deletes the object if inactive for more than specified
    TimeSpan

NOTES
    DeleteInactiveComputers.ps1
    AUthor: Rich Johnson | StorageCraft Technology Corporation
    Last Revision: 2015-11-12

EXAMPLES

    PS> ./DisableAccounts.ps1
        This will simply run the script and process disabled users.

PARAMETERS
    This script takes no parameters.

CHANGE LOG
    2015-11-12 - Added disable task, if not already disabled
               - Added Script header
    2015-11-11 - Initial creation

#>

# Location of the disabled computer accounts in Active Directory
$disabledOU = "OU=DisabledComputers,OU=Computers,OU=StorageCraft,DC=stc,DC=local"

# Import AD module if not already
If (!(Get-module ActiveDirectory )) {
    Import-Module ActiveDirectory
}

# Disable computer account if not already disabled
Get-ADComputer -Filter * -SearchBase "$DisabledOU" | Where -Property enabled | Disable-ADAccount

# All disabled computer accounts that have been inactive for 90 days
Search-ADAccount -SearchBase $disabledOU -AccountInactive -TimeSpan 90.00:00:00 | ForEach-Object { Remove-ADObject -Identity "$_" -Recursive -Confirm:$False }