#!/usr/bin/perl  -w
#eval '(exit $?0)' && eval 'exec /usr/local/bin/perl $0 ${1+"$@"}'
eval '(exit $?0)' && eval 'exec /usr/bin/perl $0 ${1+"$@"}'
#&& eval 'exec /usr/local/bin/perl $0 $argv:q'
&& eval 'exec /usr/bin/perl $0 $argv:q'
if 0;
# ============================================================================
# check_cuda_message.pl,v 1 2010/06/09 13:53:07 
# Copyright (c) 2010 Jeffrey J Jones <jeffreyjejones@gmail.com>
# All rights reserved.
# This program is free software; you may redistribute it and/or modify it
# under the same terms as Perl itself.
# ============================================================================

use XML::Simple;
use Getopt::Std;
use FileHandle;
use strict;
use vars qw($SCRIPT $VERSION %opt);
use lib "/usr/local/nagios/libexec";
use utils qw(%ERRORS $TIMEOUT);
$SCRIPT  = 'check_cuda_latency';
$VERSION = '1.0';
my $TIMEOUT=60;
my $pipe = new FileHandle;
# Validate the command line options
my $opts = 'H:w:c:';
getopts ( "$opts", \%opt );
my $host = $opt{H};
my $warn = $opt{w};
my $crit = $opt{c};
#Open connection to the barracuda
	$pipe->open("wget -o /dev/null -O - --no-check-certificate http://$host:8000/cgi-bin/stats.cgi |");
	my $barracuda = new XML::Simple->XMLin($pipe);
		(defined $barracuda) || die("Unable to parse stats XML.");
my $var = 0;
$var = $barracuda->{performance}->{last_message_minutes_ago};

if ($var >= $crit) {
print "CRITICAL Last Message was received $var Minute(s) Ago | TIME=$var\n";
exit $ERRORS{"CRITICAL"};
}
elsif ($var >= $warn) {
print "WARNING Last Message was received $var Minute(s) Ago | TIME=$var\n";
exit $ERRORS{"WARNING"};
}
else{
print "The Last Message was received $var Minute(s) Ago | TIME=$var\n";
exit $ERRORS{"OK"};
}

exit (3);

# ============================================================================
