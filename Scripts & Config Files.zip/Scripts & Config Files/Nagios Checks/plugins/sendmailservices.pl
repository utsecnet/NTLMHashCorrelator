#!/usr/bin/perl

use strict;
use MIME::QuotedPrint;
use HTML::Entities;
use Mail::Sendmail 0.75; # doesn't work with v. 0.74!

my $NOTIFICATIONTYPE = $ARGV[0];
my $SERVICEDESC = $ARGV[1];
my $HOSTALIAS = $ARGV[2];
my $HOSTADDRESS = $ARGV[3];
my $SERVICESTATE = $ARGV[4];
my $SHORTDATETIME = $ARGV[5];
my $SERVICEOUTPUT = $ARGV[6];
my $TO = $ARGV[7];
my $FROM = 'nagios@localhost.localdomain';

my $boundary = "====" . time() . "====";

my $text = "***** FAN Notification *****\n\nNotification Type: $NOTIFICATIONTYPE\n\nService: $SERVICEDESC\nHost: $HOSTALIAS\nAddress: $HOSTADDRESS\nState: $SERVICESTATE\n\nDate/Time: $SHORTDATETIME Additional Info : $SERVICEOUTPUT";

my $texthtml = " <strong>***** FAN Notification *****</strong>\n\n";

my $color = "blue";

if ( $NOTIFICATIONTYPE =~ /RECOVERY/ || $NOTIFICATIONTYPE =~ /ACKNOWLEDGEMENT/) {
    $color="#339933";
}

if ($NOTIFICATIONTYPE =~ /PROBLEM/) {
    $color="#CC0000";
}

$SERVICEOUTPUT =~ s/=/&#61;/g;

my $colorstate = "black";

# Si on a un recovery pas la peine de mettre du rouge
if ($NOTIFICATIONTYPE =~ /PROBLEM/) {
    if($SERVICESTATE =~ /CRITICAL/) {
	$colorstate = "#CC0000";
    }
    if($SERVICESTATE =~ /WARNING/) {
	$colorstate = "#CC6600";
	# pas la peine de mettre PROBLEM en rouge non plus
	$color = "#CC6600";
    }
}

$texthtml = $texthtml  . "<strong>Type</strong>: <span style='ccolor:$color'>$NOTIFICATIONTYPE</span>\n"
    . "<strong>State</strong>: <span style='color:$colorstate'>$SERVICESTATE</span>\n";

$texthtml = $texthtml  . "<strong>Service</strong>: $SERVICEDESC\n"
    . "<strong>Host</strong>: $HOSTALIAS\n"
    . "<strong>Address</strong>: $HOSTADDRESS\n\n"
    . "<strong>Date/Time</strong>: $SHORTDATETIME\n"
    . "<strong>Additional Info</strong>: $SERVICEOUTPUT";

my %mail = (
           from => $FROM,
           to => $TO,
           subject => "** $NOTIFICATIONTYPE alert - $HOSTALIAS/$SERVICEDESC is $SERVICESTATE **",
           'content-type' => "multipart/alternative; boundary=\"$boundary\""
          );

my $plain = encode_qp $text;

my $html = $texthtml;
#$html = encode_entities($texthtml);
$html =~ s/\n\n/<br \/> <br \/>\n\n/g;
$html =~ s/\n/<br \/>\n/g;
$html = "<p>" . $html . "</p>";

$boundary = '--'.$boundary;


$mail{body} = <<END_OF_BODY;
$boundary
Content-Type: text/plain; charset="utf-8"
Content-Transfer-Encoding: quoted-printable

$plain

$boundary
Content-Type: text/html; charset="utf-8"
Content-Transfer-Encoding: quoted-printable

<html><body>$html</body></html>
$boundary--
END_OF_BODY

sendmail(%mail) || print "Error: $Mail::Sendmail::error\n";

