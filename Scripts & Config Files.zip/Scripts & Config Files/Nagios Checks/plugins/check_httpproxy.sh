#!/bin/bash
#
#    Program : simulate_httpproxy.sh 
#            :
#     Author : Robert Graham (robert.graham@bt.infonet.com
#            :
#    Purpose : Nagios plugin to simulate http activity to check the
#            : proxy server. A keyword can be given that is then used
#            : to checked against the downloaded content to make sure
#            : the page accessed is the page desired.
#            :
# Parameters : --help
#            : --version
#	     : -u <User Name>
#	     : -p <Password>
#            : -proxy <ProxyServerIP:Port>
#            : -k <keyword to confirm website content (optional)>
#            : -URL <website to go to>
#            :
#    Returns : Standard Nagios status_* codes as defined in utils.sh
#            :
#      Notes :
#============:==============================================================
#        1.0 : 29 September 2006
#            : Initial coding
#
# Shamelessly stolen from other Nagios plugins.
#
PROGNAME=`basename $0`
PROGPATH=`echo $0 | /bin/sed -e 's,[\\/][^\\/][^\\/]*$,,'`
REVISION=`echo '$Revision: 1.1.1.1 $' | sed -e 's/[^0-9.]//g'`
WGET=/usr/bin/wget
#
# Default port for proxy server is 8080
#
PORT="8080"
. $PROGPATH/utils.sh

print_usage() {
	echo "Usage: $PROGNAME -u username -p password "  \
	     "-proxy ProxyIP:Port -u URL" 
	echo "Make sure to enclose username/password in quotes."    
        echo "Usage: $PROGNAME --help"
        echo "Usage: $PROGNAME --version"
}

print_help() {
        print_revision $PROGNAME $REVISION
        echo ""
        print_usage
        echo ""
        echo "Go to website over proxy with authentication."
        echo ""
        support
}


#
# If we have arguments, process them.
#
exitstatus=$STATE_WARNING #default

while test -n "$1"; do
        case "$1" in
                --help)
                        print_help
                        exit $STATE_OK
                        ;;
                -h)
                        print_help
                        exit $STATE_OK
                        ;;
		-u)	USER="$2"
			shift
			;;
		-p)	PW="$2"
			shift
			;;
		-proxy) PROXY="$2"
			shift
			;;
		-port)  PORT="$2"
			shift
			;;
		-URL)   WWWURL="$2"
			shift
			;;
                --version)
                        print_revision $PROGNAME $REVISION
                        exit $STATE_OK
                        ;;
                -V)
                        print_revision $PROGNAME $REVISION
                        exit $STATE_OK
                        ;;

                *)
                        echo "Unknown argument: $1"
                        print_usage
                        exit $STATE_UNKNOWN
                        ;;
        esac
        shift
done



#
# let Nagios know that everything is ok.
#

# Setting required by the wget tool
export http_proxy="http://"$PROXY:$PORT


#
# This is where the magic happens
#
$WGET --spider --proxy-user "$USER" --proxy-passwd "$PW" "$WWWURL"

if [ $? = "0" ]; then
   exit $STATE_OK
elif [ $? = "1" ]; then
   exit $STATE_CRITICAL
else
   exit $STATE_UNKNOWN
fi

# 
# THE END
#
