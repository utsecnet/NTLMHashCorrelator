#!/usr/bin/perl

use strict;
use MIME::QuotedPrint;
use HTML::Entities;
use Mail::Sendmail 0.75; # doesn't work with v. 0.74!

my $NOTIFICATIONTYPE = $ARGV[0];
my $HOSTNAME = $ARGV[1];
my $HOSTSTATE = $ARGV[2];
my $HOSTADDRESS = $ARGV[3];
my $HOSTOUTPUT = $ARGV[4];
my $SHORTDATETIME = $ARGV[5];
my $TO = $ARGV[6];
my $FROM = 'nagios@localhost.localdomain';

my $boundary = "====" . time() . "====";

my $text = " ***** FAN Notification *****\n\nType:$NOTIFICATIONTYPE\nHost: $HOSTNAME\nState: $HOSTSTATE\nAddress: $HOSTADDRESS\nInfo: $HOSTOUTPUT\nDate/Time: $SHORTDATETIME ";

my $texthtml = " <strong>***** FAN Notification *****</strong>\n\n";

my $color = "blue";

if ($NOTIFICATIONTYPE =~ /RECOVERY/) {
    $color = "#339933";
} 

if ($NOTIFICATIONTYPE =~ /PROBLEM/) {
    $color = "#CC0000";
}

$HOSTOUTPUT =~ s/=/&#61;/g;

$texthtml = $texthtml  . "<strong>Type</strong>: <span style='ccolor:$color'>$NOTIFICATIONTYPE</span>\n";

$texthtml = $texthtml  . "<strong>Host</strong>: $HOSTNAME\n"
    . "<strong>State</strong>: $HOSTSTATE\n"
    . "<strong>Address</strong>: $HOSTADDRESS\n"
    . "<strong>Info</strong>: $HOSTOUTPUT\n"
    . "<strong>Date/Time</strong>: $SHORTDATETIME ";

my %mail = (
           from => $FROM,
           to => $TO,
           subject => "Host $HOSTSTATE alert for $HOSTNAME!",
           'content-type' => "multipart/alternative; boundary=\"$boundary\""
          );

my $plain = encode_qp $text;

my $html = $texthtml;
#$html = encode_entities($texthtml);
$html =~ s/\n\n/<br\/><br\/>\n\n/g;
$html =~ s/\n/<br\/>\n/g;
$html = "<p>" . $html . "</p>";

$boundary = '--'.$boundary;

$mail{body} = <<END_OF_BODY;
$boundary
Content-Type: text/plain; charset="utf-8"
Content-Transfer-Encoding: quoted-printable

$plain

$boundary
Content-Type: text/html; charset="utf-8"
Content-Transfer-Encoding: quoted-printable

<html><body>$html</body></html>
$boundary--
END_OF_BODY

sendmail(%mail) || print "Error: $Mail::Sendmail::error\n";

